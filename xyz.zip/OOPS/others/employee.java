import java.util.*;

class Details
{
    private String name,gender;
    public Details(String name,String gender)
    {
    	this.name=name;
    	this.gender=gender;
    }

    void getDetails()
    {
    	System.out.println("Name: "+name+"\ngender: "+gender);
    }
}

public class Employee
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
        
		Map<Integer,Deatails> mp=new HashMap<>();
		mp.put(1,new Details("Sursh","M"));
		mp.put(2,new Details("Ramesh","M"));
		mp.put(3,new Details("Geeta","F"));

        i=10;
        while(i<10)
        {
        	System.out.print("Enter the emp Id: ");
        	int id=sc.nextInt();
        	if(mp.containsKey(id))
        	{
        		Details d=mp.get(id);
        		d.getDetails();
        	}
        	else
        		System.out.println("Not Found!");
        	i++;
        }
	}

}