import java.util.*;

class Book
{
	String Book_Title,Book_Author;
	int ISBN_no,Book_Count;

	public Book(String Book_Title,String Book_Author,int ISBN_no,int Book_Count)
	{
		this.Book_Title=Book_Title;
		this.Book_Author=Book_Author;
		this.ISBN_no=ISBN_no;
		this.Book_Count=Book_Count;
	}
}

class Customer
{
	String User_name,password;
	String Customer_Name;
	int Customer_Id;

	public Customer(String User_name,String password,String Customer_Name,int Customer_Id)
	{
		this.User_name=User_name;
		this.password=password;
		this.Customer_Name=Customer_Name;
		this.Customer_Id=Customer_Id;
	}
}

public class lab1
{
	public static void main(String args[])
	{
		  ArrayList<Book> book=new ArrayList<>();
        ArrayList<Customer> customer=new ArrayList<>();
        Map<Book,Customer> trans=new HashMap<>();

		Scanner sc=new Scanner(System.in);

        book.add(new Book("DBMS","GNANE",1000,5));
        book.add(new Book("OOPS","SHIV",1001,10));

        customer.add(new Customer("user1","pass1","Ram",1234));
        customer.add(new Customer("user2","pass2","Krish",1235));

        int f=1;
        while(f==1)
        {
        System.out.print("Enter username:");
        String username=sc.next();
        System.out.print("Enter password: ");
        String pass=sc.next();

        for(Customer c: customer)
        {
        	if(username.equals(c.User_name) && pass.equals(c.password))
        	{
        		System.out.println("   Welcome   ");
        		f=0;break;
        	}
        }
        if(f==1)
        {
        	System.out.println("Username Not Found!!");
        }
        if(f==0) break;

        }
        
        int exit=1;
        while(exit==1)
        {
           System.out.print("Enter the book name to purchase: ");
           String book_name=sc.next();

           int flag=1;
           for(Book b: book)
           {
           	  if(b.Book_Title.equals(book_name))
           	  {
           	  	 System.out.println("Book has found!");
           	  	 System.out.println(book_name+" has been purchased");
           	  	 b.Book_Count-=1;
           	  	 System.out.println("Remaining: "+b.Book_Count);
           	  	 flag=0;break;
           	  }
           }
              if(flag==1)
           	  {
           	  	System.out.println("Sorry book has not found!!");
           	  }

           	  System.out.println("exit?(0/1) :");
           	  exit=sc.nextInt();
        }
        System.out.println("ThankYou");
	}
}