import java.util.*;

class Add
{
	public Map<String,Integer> mp;
    //public List<String> mp;

    public Add()
    {
    mp=new HashMap<>();

    mp.put("abc",1);
    mp.put("cde",2);
    }
	
}

public class MixedObject
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);

		List<Add> mixedList=new ArrayList<>();
		//mixedList.add(1234);
		//mixedList.add("String");

		mixedList.add(new Add());

		for(Add o: mixedList)
		{
            for(Map.Entry<String,Integer> i: o.mp.entrySet())
            	System.out.println(i.getKey()+"  "+i.getValue());
		}	
	}
}