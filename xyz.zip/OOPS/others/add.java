import java.util.*;

public class add
{
  public static void main(String[] args)
  {
   Scanner scanner=new Scanner (System.in);

   System.out.print("Enter 1st no: ");
   int a=scanner.nextInt();
   
   System.out.print("Enter 2nd no: ");
   int b=scanner.nextInt();

   int sum=a+b;

   System.out.println("Sum ="+sum);
   scanner.close();
  }
}
