import java.util.*;

public class indexOf{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);

		String text=sc.next();
		char ch=sc.next().charAt(0);

		int index=text.indexOf(ch);
		int freq=0;
		while(index!=-1)
		{
			freq++;
			index=text.indexOf(ch,index+1);
		}
		System.out.println("freq of "+ch+" :"+freq);
	}
}