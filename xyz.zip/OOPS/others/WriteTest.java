import java.util.*;

abstract class TestQuestion
{
    public int q_no,point;
	abstract public boolean isCorrect(int option);
}

class MultiChoice extends TestQuestion
{
	int crt;

	public MultiChoice(int q_no,String question,String[] s,int crt,int point)
	{
		this.q_no=q_no;
		System.out.println(q_no+"."+question);
		for(int i=0;i<s.length;i++)
		{
			System.out.print(i+1+"."+s[i]);
		}
        this.crt=crt;
        this.point=point;
	}

	public boolean isCorrect(int option)
	{
		if(option==crt)  
		{
			return true;
		}
		else{
			return false;
		}
	}
}

public class WriteTest
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		ArrayList<MultiChoice> mc=new ArrayList<>();
		int ans=0;

        for(int i=0;i<2;i++)
        {
        	String[] ch={"Stack","Heap","Registers","ROM"};
        	mc.add(new MultiChoice(1,"Where do primitive data type values be stored?",ch,1,1));
        	int choice=sc.nextInt();
		    if(mc.get(i).isCorrect(choice))  ans++;  
        }
         System.out.println(ans);
	}
}