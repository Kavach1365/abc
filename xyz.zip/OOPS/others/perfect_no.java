import java.util.*;

public class perfect_no{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner (System.in);
        System.out.println("Enter no:");
        long N=sc.nextInt();

       long sum=01;
       for(int i=02;i<Math.sqrt(N);i++)
       {
           if(N%i==0) 
           {
            sum+=N/i;
            sum+=i;
           }
       }
       if(sum==N) System.out.println("YES");
       else System.out.println("NO");
    }
}