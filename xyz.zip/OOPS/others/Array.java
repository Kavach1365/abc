import java.util.*;

public class Array {
    public static void main(String [] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the size:");
        int n=sc.nextInt();

        int[] a=new int[n];
        System.out.print("Enter elemts:");
        for(int i=0;i<n;i++)
           a[i]=sc.nextInt();
           
        Arrays.sort(a);
        for(int i=0;i<n;i++)  
           System.out.print(a[i]+" ");

    }
}
