import java.util.*;

class Product
{
	String product_name;
    int product_id,product_quantity;
    double product_price;

    public Product(int id,String name,int quant,double price)
    {
    	this.product_id=id;
    	this.product_name=name;
    	this.product_quantity=quant;
    	this.product_price=price;
    }
}

public class ProductPrice
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);

		Map<Integer,Product> p=new HashMap<>();
		p.put(1,new Product(1,"prod1",10,100.0));
		p.put(2,new Product(2,"prod2",15,150.0));

		double total=0,i=2;
        System.out.println("Enter product ids & quant sold: ");
		while(i-->0)
		{
           int id=sc.nextInt();
           int quant=sc.nextInt();
           
           if(p.containsKey(id))
           {
           	 System.out.println("retail value: "+quant*(p.get(id).product_price));
           	 total+=quant*p.get(id).product_price;
           }
		}
		System.out.println("Total retail value: "+total);
	}
}