import java.util.*;

public class CommandLine
{
	public static void main(String args[])
	{
		
		// for(int i=0;i<args.length;i++)
		// {
		// 	for(int j=0;j<args.length-1;j++)
		// 	{
		// 		if(args[j+1].compareTo(args[j])<0)
		// 		{
		// 			String temp=args[j+1];
		// 			args[j+1]=args[j];
		// 			args[j]=temp;
		// 		}
		// 	}
		// }
		Arrays.sort(args);
		for(int i=0;i<args.length;i++)
			System.out.println(args[i]);
	}
}