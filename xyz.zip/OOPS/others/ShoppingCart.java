import java.util.*;

interface Product
{
	public String getProductName();
	public double getPrice();
}

class Book implements Product
{
    String author,productName;
    double price;
    
    public Book(String name,String auth,double price)
    {
        productName=name;
        this.price=price;
        author=auth;
    }

    public String getProductName()
    {
    	return productName;
    } 
    public double getPrice()
    {
    	return this.price;
    }
}

class Electronic implements Product
{
	String manufacturer;
	String productName;
        double price;

	public Electronic(String name,String man,double price)
	{
        productName=name;
        this.price=price;
        manufacturer=man;
	} 

	public String getProductName()
	{
		return productName;
	}
	public double getPrice()
	{
		return this.price;
	}
}

public class ShoppingCart
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);

		List<Product> products=new ArrayList<>();

		products.add(new Book("The Cather in the Rye","john",25.0));
	    products.add(new Book("To Kil a MockingBord","Will",20.0));
	    products.add(new Book("Hills in the Sky","Cook",50.0));

	    products.add(new Electronic("HP231","hp",50000.0));
	    products.add(new Electronic("Redmi9","redmi",17500.0));

	    List<Product> cart=new ArrayList<>();
        System.out.println("Select  products to add to cart : ");
                   for(int i=0;i<products.size();i++)
                   {
                   	  System.out.println(i+1+"."+products.get(i).getProductName());
                   }
                   
                   int exit=01;
                   while(exit!=0){
                   	  exit=sc.nextInt();
                   	  if(exit!=0){
                   	  for(int i=1;i<=products.size();i++)
                   	  
                   	  {
                   	  	if(exit==i){
                   	  	 cart.add(products.get(i-1));
                   	  	 System.out.println(products.get(i-1).getProductName()+" added to cart.");
                   	  	 break;
                   	  	}
                     
                   	  }
                   	}
                   }
                   System.out.println("Products in the cart are: ");
                   for(Product p: cart)
                    	System.out.println("Name: "+p.getProductName()+","+p.getPrice());
}
}

