import java.util.*;

public class nextLine
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);

		String s=sc.nextLine();
		int v=0,c=0,dig=0,others=0;
		String text=s.toLowerCase();
		System.out.println(text);

		for(int i=0;i<text.length();i++)
		{
			if(text.charAt(i)=='a' || text.charAt(i)=='e' || text.charAt(i)=='i' || text.charAt(i)=='o' || text.charAt(i)=='a'||text.charAt(i)=='u')
				v++;
			else if(text.charAt(i)>='a' && text.charAt(i)<='z') c++;
			else if(text.charAt(i)>='0' && text.charAt(i)<='9') dig++;
			else others++;
		}
		System.out.println("Vowels: "+v+"\nConsonants: "+c+"\ndig: "+dig+"\nothers: "+others);
	}
}