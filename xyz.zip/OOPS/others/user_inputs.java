import java.util.Scanner;

public class UserInputExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking input for integer
        System.out.print("Enter an integer: ");
        int intValue = scanner.nextInt();
        System.out.println("You entered: " + intValue);

        // Taking input for double
        System.out.print("Enter a double: ");
        double doubleValue = scanner.nextDouble();
        System.out.println("You entered: " + doubleValue);

        // Taking input for string
        System.out.print("Enter a string: ");
        String stringValue = scanner.next(); // Reads the next token (word)
        System.out.println("You entered: " + stringValue);

        // Taking input for boolean
        System.out.print("Enter a boolean (true/false): ");
        boolean booleanValue = scanner.nextBoolean();
        System.out.println("You entered: " + booleanValue);

        // Taking input for character
        System.out.print("Enter a character: ");
        char charValue = scanner.next().charAt(0); // Reads the first character of the input
        System.out.println("You entered: " + charValue);

        // Close the scanner to release resources
        scanner.close();
    }
}
