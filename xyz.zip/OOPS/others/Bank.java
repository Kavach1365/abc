import java.util.*;

class SBI
{
	String bank_name,branch_name,acct_name;
	double acct_no,acct_bal;

	public SBI(String bank_name,String branch_name,String acct_name,double acct_no,double acct_bal)
	{
		this.bank_name=bank_name;
		this.branch_name=branch_name;
		this.acct_name=acct_name;
		this.acct_no=acct_no;
		this.acct_bal=acct_bal;
	}

	public void credit(double amount)
	{
		acct_bal+=amount;
	}
	public void debit(double amount)
	{
		if(amount>acct_bal)
			System.out.println("Debit amount exceeded account balance.");
		else
			acct_bal-=amount;
	}
	public double getBalance()
	{
		return acct_bal;
	}
}

public class Bank
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);

		ArrayList<SBI> bank=new ArrayList<>();
		bank.add(new SBI("SBI","Basar","Suresh",12345,1000.0));
		bank.add(new SBI("SBI","Basar","Ramesh",12346,1000.0));

		bank.add(new SBI("SBI","Nzb","Ramya",12347,1000.0));
		bank.add(new SBI("SBI","Nzb","Megha",12348,1000.0));

        int f=0;
		while(f==0)
		{
			System.out.print("Enter username: ");
			String username=sc.next();
			System.out.print("Enter password: ");
			double  pass=sc.nextDouble();

            
			for(SBI b: bank)
			{
				if(b.branch_name.equals(username) && b.acct_no==pass)
				{
					System.out.println("        WELCOME  "+b.acct_name);
                    
                    int exit=1;
                    while(exit==1){
					System.out.println("Choose the operations:\n1.Credit\n2.Debit\n3.Balance Enquiry\n4.exit");
					int  choice=sc.nextInt();

					switch(choice)
					{
					     case 1:
					     	System.out.print("Enter the amount: ");
					     	double camount=sc.nextDouble();
					     	b.credit(camount);
					     	break;

					     case 2:
					     	System.out.print("Enter the amount: ");
					     	double damount=sc.nextDouble();
					     	b.debit(damount);
					     	break;
					    case 3:

					     	System.out.println(b.getBalance());
					     	break;
					    case 4:
					    	exit=0;
					    	break;
					}
				}
					f=1;
					break;
				}
			}
			if(f==1)
			{
               break;
			}
			else
			{
				System.out.println("Invalid Credentials!!");
			}
		}
	}
}

