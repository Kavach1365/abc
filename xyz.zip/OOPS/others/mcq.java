import java.util.*;

public class mcq{
    int x;
    mcq(int a)
    {
        x=a;
    }
    public static void main(String args[])
    {
        mcq obj1=new mcq(5);
        
    }
    System.out.print(x);
}