import java.util.*;

class Employee 
{
    private String name;
    private int age;
    private String gender;
    private String designation;
    private double salary;
    private String address;

    public Employee(String name, int age, String gender, String designation, double salary, String address)
    {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.designation = designation;
        this.salary = salary;
        this.address = address;
    }

  
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getDesignation() {
        return designation;
    }

    public double getSalary() {
        return salary;
    }

    public String getAddress() {
        return address;
    }
}



public class EmployeeDetails 
{
    public static void main(String[] args) 
    {
        Scanner sc=new Scanner(System.in);
        Map<Integer, Employee> employeeMap = new HashMap<>();

        System.out.print("Enter the no.of emp's :");
        int n=sc.nextInt();
        
        System.out.println("Enter their Details:");
        while(n>0)
        {
          int ID=sc.nextInt();
          /*if (employeeMap.containsKey(ID))
              System.out.println("Duplicate ID!! Please Enter valid one.");
          else*/
          {
          String name=sc.next();
          int age=sc.nextInt();
          String gender=sc.next();
          String designation=sc.next();
          double salary=sc.nextDouble();
          String address=sc.next();
          
          employeeMap.put(ID, new Employee(name,age,gender,designation,salary,address));
          n--;
          }
       }

        System.out.print("Enter the req emp.ID : ");
        int requiredEmployeeId = sc.nextInt();

        
        if (employeeMap.containsKey(requiredEmployeeId))
        {
            Employee requiredEmployee = employeeMap.get(requiredEmployeeId);
            System.out.println("EMPLOYEE DETAILS FOR ID " + requiredEmployeeId + ":");
            System.out.println("Name: " + requiredEmployee.getName());
            System.out.println("Age: " + requiredEmployee.getAge());
            System.out.println("Gender: " + requiredEmployee.getGender());
            System.out.println("Designation: " + requiredEmployee.getDesignation());
            System.out.println("Salary: " + requiredEmployee.getSalary());
            System.out.println("Address: " + requiredEmployee.getAddress());
        }
         else 
         {
            System.out.println("Employee with ID " + requiredEmployeeId + " not found.");
         }
         
         //System.out.println(employeeMap.get(requiredEmployeeId));
    }
}

