import java.util.*;

public class lab312
{
   public static void main(String[] args)
   {
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter no.of i/p no's :");
      int n=sc.nextInt();
      
      Map<Integer,Integer> mp=new HashMap<>();
      
      System.out.print("Enter no's :  ");
      int size=0;
      while(n-->0)
      {
        int num=sc.nextInt();
        if(mp.containsKey(num)==false)
        {
           mp.put(num,1);
           size++;
        }
      }
      
      System.out.print("Unique values are : ");
      for (Map.Entry<Integer, Integer> i : mp.entrySet()) 
        {  
            System.out.print(i.getKey() + " ");  
        } 
   }
} 
