import java.util.*;

public class lab38
{
   public static void main(String[] args)
   {
      Scanner sc=new Scanner(System.in);
      
      System.out.print("Enter string1 : ");
      String s1=sc.next();
      
      System.out.print("Enter string2 : ");
      String s2=sc.next();
      int n=s2.length();
      
      int i=0,f=0;
      while(i<s1.length()-n)
      {
        System.out.println(s1.substring(i,i+n));
        if(s1.substring(i,i+n).equals(s2))
        {
          
          f=1;break;
        }
        i++;
      }
      if(f==1) System.out.println("Found from idx "+i);
      else System.out.println("Not Found");
   }
} 
