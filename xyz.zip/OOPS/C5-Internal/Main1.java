import java.util.*;
import java.lang.*;


class Book{
	String BookTitle;
	int ISBN_No;
	int BookCnt;
	String Author;
	Book(String a, int b, String c, int d){
		BookTitle=a; ISBN_No=b; Author=c; BookCnt=d;
	}

	void buyBook(){
		System.out.println("\tBook has been Purchased...");
	}
}


class Customer{
	String username, password, adress, custName;
	int custId;
	Customer(String a, String b, String c, int d, String e){
		username=a; password=b; adress=c; custId=d; custName=e;
	}

	void buyBook(Book book){
		System.out.println("\t Customer with customerId " + custId + " is Buying Book...");
		
		book.buyBook();
	}
}


class Main1{
	public static void main(String[] args){
		Vector<Book> Books=new Vector<Book>();
		Books.add(new Book("Doremon", 1234, "Nithin", 12));
		Books.add(new Book("Ben 10", 12564, "mahesh", 2));
		Books.add(new Book("my Biography", 1234, "vamshi", 0));

		Vector<Customer> Customers=new Vector<Customer>();
		Customers.add(new Customer("Nithin", "Nithin123", "hNo: 5-4, Nalgonda", 1, "Nithin"));
		Customers.add(new Customer("vamshi", "vamshi321", "hNo: 5-4, USA", 1, "Vamshi"));
		Customers.add(new Customer("Shivamani", "Shiva12@", "Nizambad", 1, "Shivamani"));

		Scanner input=new Scanner(System.in);
		System.out.print("Enter Username: ");
		String username=input.next();
		System.out.print("Enter Password: ");
		String password=input.next();


		for(Customer customer: Customers){
			if(customer.username.equals(username)==true && customer.password.equals(password)==true){
				System.out.println("\t !Welcome, " + customer.custName);
					Customer myObj=customer;
					boolean exit=true;
					while(exit==true){
						System.out.print("Enter the Book Name You want: ");
						String userWantedBook=input.next();
						boolean flag=false;
						for(Book book: Books){
							if(book.BookTitle.contains(userWantedBook)==true){
								myObj.buyBook(book);
								flag=true;
								break;
							}
						}
						System.out.print("Do you wnat to continue Pusrchase: true/false? ");
						exit=input.nextBoolean();
					}
			}
		}
	}
}

