package sounds;

public class Podcast{

	public void playPodcast(String s){
		
		System.out.println("Playing " + s +  " sounds...");
	}
}