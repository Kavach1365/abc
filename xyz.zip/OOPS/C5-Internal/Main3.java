
import sounds.Podcast;
import java.util.*;
import java.lang.*;

class Main3{
	public static void main(String[] args){
		Podcast songs=new Podcast();
		Scanner input=new Scanner(System.in);
		String s=input.next();
		songs.playPodcast(s);
	}
}