package sounds;

interface Dolby{
	abstract void playDolby();
}