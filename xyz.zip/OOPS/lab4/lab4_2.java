import java.util.*;

class Person
{
   public String name;
   public String address;
   
   public Person(String name,String address)
   {
     this.name=name;
     this.address=address;
   }
   
   public String getName()
   {
     return name;
   }
   public String getAddress()
   {
     return address;
   }
   void setAddress(String address)
   {
     this.address=address;
   }
}

class Student extends Person
{
   List<String> courses=new ArrayList<>();
   List<Integer> grades=new ArrayList<>();
   
   public Student(String name,String address)
   {
     super(name,address);
   }
   
   public void addCourseGrade(String course,int grade)
   {
     if(courses.size()==30)
       System.out.println("Can't be added");
       
     else
     {
       courses.add(course);
       grades.add(grade);
       System.out.println("added Successfully");
     }
   }
   
   public void printGrades()
   {
     for(int i: grades)
       System.out.println(i);
   }
   
   public double getAverageGrade()
   {
     int sum=0;
     for(int i: grades)
       sum+=i;
       
     return (double)sum/grades.size();
   }
}

class Teacher extends Person
{
   List<String> courses=new ArrayList<>();
   
   Teacher(String name,String address)
   {
     super(name,address);
   }
   
   boolean addCourse(String course)
   {
      for(String i: courses)
      {
        if(i==course)
          return false;
      }
      courses.add(course);
      return true;
   }
   
   boolean removeCourse(String course)
   {
      for(String i: courses)
      {
        if(i==course)
        {
          courses.remove(i);
          return true;
        }
      }
      return false;
   }
}

class lab4_2
{
  public static void main(String args[])
  {
    Student stu=new Student("Hari","Hyd");
    stu.addCourseGrade("OOP",9);
    stu.addCourseGrade("FLAT",8);
    stu.printGrades();
    System.out.println(stu.getAverageGrade());
    
    Teacher t1=new Teacher("Santhosh","Mdk");
    String[] courses = {"IM101", "IM102", "IM101"};
    
    for (String course: courses) 
    {
     if (t1.addCourse(course))
        System.out.println(course + " added.");
     else
        System.out.println(course + " cannot be added.");
    }
    
    for (String course: courses)
        if (t1.removeCourse(course))
           System.out.println(course + " removed.");
  }
}
   
   
