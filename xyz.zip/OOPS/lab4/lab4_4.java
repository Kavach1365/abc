import java.util.*;

class Vehicle {
    protected String company;
    protected String model;
    protected double mileage;
    protected double fuelCapacity;
    protected double displacement;

    public Vehicle(String company, String model, double mileage, double fuelCapacity, double displacement) {
        this.company = company;
        this.model = model;
        this.mileage = mileage;
        this.fuelCapacity = fuelCapacity;
        this.displacement = displacement;
    }

    public void displayDetails() {
        System.out.println("Company: " + company);
        System.out.println("Model: " + model);
        System.out.println("Mileage: " + mileage + " km/l");
        System.out.println("Fuel Capacity: " + fuelCapacity + " liters");
        System.out.println("Displacement: " + displacement + " cc");
    }
}

class TwoWheeler extends Vehicle {
    private String frontBrake;
    private String rearBrake;
    private String tyreType;
    private String headLamp;
    private String userReviews;

    public TwoWheeler(String company, String model, double mileage, double fuelCapacity, double displacement,
                      String frontBrake, String rearBrake, String tyreType, String headLamp, String userReviews) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.frontBrake = frontBrake;
        this.rearBrake = rearBrake;
        this.tyreType = tyreType;
        this.headLamp = headLamp;
        this.userReviews = userReviews;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Front Brake: " + frontBrake);
        System.out.println("Rear Brake: " + rearBrake);
        System.out.println("Tyre Type: " + tyreType);
        System.out.println("Head Lamp: " + headLamp);
        System.out.println("User Reviews: " + userReviews);
    }
}

class FourWheeler extends Vehicle {
    private boolean airConditioner;
    private boolean airBags;
    private boolean powerSteering;
    private boolean rainSensingWiper;

    public FourWheeler(String company, String model, double mileage, double fuelCapacity, double displacement,
                       boolean airConditioner, boolean airBags, boolean powerSteering, boolean rainSensingWiper) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.airConditioner = airConditioner;
        this.airBags = airBags;
        this.powerSteering = powerSteering;
        this.rainSensingWiper = rainSensingWiper;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Air Conditioner: " + (airConditioner ? "Yes" : "No"));
        System.out.println("Air Bags: " + (airBags ? "Yes" : "No"));
        System.out.println("Power Steering: " + (powerSteering ? "Yes" : "No"));
        System.out.println("Rain Sensing Wiper: " + (rainSensingWiper ? "Yes" : "No"));
    }
}

public class lab4_4 {
    public static void main(String[] args) {
        List<Vehicle> vehicles = new ArrayList<>();
        
        // Adding 2-wheelers
        vehicles.add(new TwoWheeler("Honda", "Activa", 60.0, 5.3, 109.51,
                "Disc", "Drum", "Tubeless", "LED", "Positive"));
        vehicles.add(new TwoWheeler("Suzuki", "Access", 55.0, 5.0, 124.0,
                "Disc", "Drum", "Tubeless", "Halogen", "Excellent"));
        
        // Adding 4-wheelers
        vehicles.add(new FourWheeler("Toyota", "Camry", 23.0, 55.0, 2487.0,
                true, true, true, true));
        vehicles.add(new FourWheeler("Honda", "City", 18.0, 50.0, 1498.0,
                true, true, true, true));

        // Displaying all available vehicles
        System.out.println("Available Vehicles:");
        for (int i = 0; i < vehicles.size(); i++) {
            System.out.println((i + 1) + ". " + vehicles.get(i).company + " " + vehicles.get(i).model);
        }

        // User input for vehicle comparison
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nEnter the numbers of the vehicles you want to compare (comma-separated):");
        String userInput = scanner.nextLine();
        String[] selectedNumbers = userInput.split(",");

        // Comparing and displaying the selected vehicles
        System.out.println("\nComparison Result:");
        for (String number : selectedNumbers) {
            int index = Integer.parseInt(number.trim()) - 1;
            if (index >= 0 && index < vehicles.size()) {
                vehicles.get(index).displayDetails();
                System.out.println("--------------------");
            } else {
                System.out.println("Invalid selection: " + number);
            }
        }
    }
}

