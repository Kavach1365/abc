package sounds; 

public class Podcast
{
	public void playPodcast(String song)
	{
		System.out.println("Playing XXXXX....");
	}
}