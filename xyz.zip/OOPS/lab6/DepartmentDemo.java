import dept.CSE;
import dept.ECE;

public class DepartmentDemo
{
	public static void main(String[] args)
	{
		CSE cse=new CSE();
		ECE ece=new ECE();

		cse.display_subjects();
		ece.display_subjects();
	}
}