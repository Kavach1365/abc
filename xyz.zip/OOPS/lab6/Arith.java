package complex;

public class Arith
{
	public int rp,ip; 

	public Arith()
	{
		rp=0;
		ip=0;
	}

	public Arith(int rp,int ip)
	{
		this.rp=rp;
		this.ip=ip;
	}

	public Arith add(Arith a1,Arith a2)
	{
		Arith result1=new Arith();
		result1.rp=a1.rp+a2.rp;
		result1.ip=a1.ip+a2.ip;
		return result1;
	} 
	public Arith sub(Arith a1,Arith a2)
	{
		Arith result2=new Arith();
		result2.rp=a1.rp-a2.rp;
		result2.ip=a1.ip-a2.ip;
		return result2;
	} 

	public void display()
	{
		System.out.println(rp+"+"+ip+"i");
	}
}