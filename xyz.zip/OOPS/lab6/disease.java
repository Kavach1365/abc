package M_Seva;

public interface disease
{
	public void identify_disease();
}

