import java.util.*;
//import calculator.CalculatorOperations;
import calculator.BasicOperations;

public class Calculator
{
   public static void main(String[] args)
   {
      BasicOperations calculator = new BasicOperations();
      
      System.out.println(calculator.add(5,5));
      System.out.println(calculator.subtract(5,5));
   }
}
