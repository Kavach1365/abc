package sounds;

public interface dolby
{
	public void playDolby(String song);
}