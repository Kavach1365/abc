package M_Seva;
import java.util.*;

public class PC implements disease
{
	public List<String> pcsymp=new ArrayList<>();

	public PC(List<String> pc)
	{
		this.pcsymp=pc;
	}

	public void identify_disease()
	{
		
			System.out.println("PC");
	}
	public List<String> getList()
	{
		return pcsymp;
	}
}