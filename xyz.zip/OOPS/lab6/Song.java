import sounds.Podcast;

public class Song
{
	public static void main(String[] args)
	{
		Podcast play=new Podcast();
		play.playPodcast("XXXXX");
	}
}
