package dept;

public class CSE implements Department
{
	public void display_subjects()
	{
		System.out.println("PPS");
		System.out.println("DBMS");
	}
}