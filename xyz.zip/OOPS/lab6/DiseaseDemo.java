import java.util.*;

import M_Seva.AP;
import M_Seva.A;
import M_Seva.PC;

public class DiseaseDemo
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);

		//List<String> userSymp=new ArrayList<>();

		AP ap=new AP(Arrays.asList("Muscle ache","fever"));
		A a=new A(Arrays.asList("fever","fatigue"));
		PC pc=new PC(Arrays.asList("fatigue","fever"));

        System.out.print("Enter symptoms: ");
		String userInput = sc.nextLine();
        List<String> userSymp = Arrays.asList(userInput.split(","));

        if(ap.ap_symp.containsAll(userSymp))
        	ap.identify_disease();
        if(a.asymp.containsAll(userSymp))
        	a.identify_disease();
        if(pc.pcsymp.containsAll(userSymp))
        	pc.identify_disease();

	}
}