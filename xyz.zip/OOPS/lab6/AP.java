package M_Seva;
import java.util.*;

public class AP implements disease
{
	public List<String> ap_symp=new ArrayList<>();

	public AP(List<String> ap)
	{
		this.ap_symp=ap;
	}

	public void identify_disease()
	{
			System.out.println("AP");
	}
	public List<String> getList()
	{
		return ap_symp;
	}
}