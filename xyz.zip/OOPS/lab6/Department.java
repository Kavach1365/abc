package dept;

public interface Department
{
	public void display_subjects();
}