import complex.Arith;
import java.util.*;

public class Complex
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		Arith arith=new Arith();

		System.out.print("Enter real & im part of 1st no: ");
		int r1=sc.nextInt();
		int i1=sc.nextInt();

		System.out.print("Enter real & im part of 2nd no: ");
		int r2=sc.nextInt();
		int i2=sc.nextInt();

	    Arith a1=new Arith(r1,i1);
	    Arith a2=new Arith(r2,i2);

	    a1.display();a2.display();

        System.out.print("Added value: ");
        Arith res1=arith.add(a1,a2);
        res1.display();

        System.out.print("Subtracted value: ");
        Arith res2=arith.sub(a1,a2);
        res2.display();

	}
	
}
