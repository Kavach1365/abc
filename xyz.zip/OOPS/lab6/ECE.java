package dept;

public class ECE implements Department
{
	public void display_subjects()
	{
		System.out.println("DEC");
		System.out.println("AEC");
	}
}