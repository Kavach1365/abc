package calculator;

public class BasicOperations implements CalculatorOperations
{
   public double add(int a,int b)
   {
      return (a*1.0+b);
   }
   public double subtract(int a,int b)
   {
      return (a*1.0-b);
   }
}
