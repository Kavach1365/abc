package calculator;

public interface CalculatorOperations
{
   public double add(int n1,int n2);
   public double subtract(int n1,int n2);
}
