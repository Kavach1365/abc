package M_Seva;
import java.util.*;

public class A implements disease
{
	public List<String> asymp=new ArrayList<>();

	public A(List<String> a)
	{
		this.asymp=a;
	}

	public void identify_disease()
	{
		
			System.out.println("A");
	}
	public List<String> getList()
	{
		return asymp;
	}
}