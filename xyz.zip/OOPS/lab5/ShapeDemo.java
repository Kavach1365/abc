import java.util.*;

abstract class Shape
{
	public abstract double getArea();
	public abstract double getVolume();
}

class Square extends Shape
{
	private double side;
	public Square(double side)
	{
		this.side=side;
	}
	
	public double getArea()
	{
        return side*side;
	}
	public double getVolume()
	{
	return 0;
	}
}

class Circle extends Shape
{
	private double radius;
	public Circle(double r)
	{
		this.radius=r;
	}
	public double getArea()
	{
        return 3.14*radius*radius;
	}
	public double getVolume()
	{
	return 0;
	}
}
class Cube extends Shape
{
	private double  side;
	public Cube(double side)
	{
		this.side=side;
	}
	public double getArea()
	{
        return 6*side*side;
	}
	public double getVolume()
	{
	 return	side*side*side;
	}
}
class Sphere extends Shape
{
	private double  radius;
	public Sphere(double r)
	{
		this.radius=r;
	}
	public double getArea()
	{
        return 4.0*3.14*radius*radius;
	}
	public double getVolume()
	{
		return (4.0/3.0)*3.14*radius*radius*radius;
	}
}

public class ShapeDemo
{
	public static void main(String[] args)
	{
		Square sq=new Square(4.0);
		Circle c=new Circle(4.0);
		Cube cb=new Cube(4.0);
		Sphere sp=new Sphere(4.0);

		System.out.println(sq.getArea());
        System.out.println(c.getArea());
        System.out.println(cb.getArea()+" "+cb.getVolume());
        System.out.println(sp.getArea()+" "+sp.getVolume());
	}
}
