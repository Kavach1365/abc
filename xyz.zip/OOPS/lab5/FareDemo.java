import java.util.*;

interface Fare
{
	public void getFare();
}

class Bus implements Fare 
{
	private double FarePerKm,distance;
	private String  Type;

	public Bus(double distance,int choice)
	{
         this.Type=Type;
         this.distance=distance;
	
	switch(choice)
	{
	case 1:
		this.Type="A/c";
		this.FarePerKm=15.0;
		break;
	case 2:
		this.Type="Non-A/c";
		this.FarePerKm=10.0;
		break;
	case 3:
		this.Type="Sleeper";
		this.FarePerKm=12.0;
		break;
	}
    }
	public void getFare()
	{
		System.out.println("Type: "+Type+"\nFarePerKm: "+FarePerKm
	    +"\nTotalFare: "+(distance*FarePerKm*1.0));
	}
}

class Train implements Fare
{
	private double FarePerKm,distance;
	private String  Type;
	public int choice;

	public Train(double distance,int choice)
	{
         this.Type=Type;
         this.choice=choice;
         this.distance=distance;

	switch(choice)
	{
	case 1:
		this.Type="A/c";
		this.FarePerKm=10.0;
		break;
	case 2:
		this.Type="Non-A/c";
		this.FarePerKm=6.0;
		break;
	case 3:
		this.Type="Sleeper";
		this.FarePerKm=8.0;
		break;
	}

    }
	public void getFare()
	{
		System.out.println("Type: "+Type+"\nFarePerKm: "+FarePerKm
	    +"\nTotalFare: "+(distance*FarePerKm*1.0));
	}
}

public class FareDemo
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);

        int i=5;
		while(i-->0)
		{
			System.out.println("Select transporation mode:\n1.BUS\n2.TRAIN");
            int ch=sc.nextInt();
            System.out.println("Select Type:\nA/c\n2.Non-A/c\n3.Sleeper");
                	int choice=sc.nextInt();
                	System.out.print("Enter the dist: ");
                    double distance=sc.nextInt();

            switch(ch)
            {
                case 1:
                    Bus bus=new Bus(distance,choice);
                    bus.getFare();
                    break;

                case 2:
                    Train train=new Train(distance,choice);
                    train.getFare();
                    break;
            }
		}
	}
}
