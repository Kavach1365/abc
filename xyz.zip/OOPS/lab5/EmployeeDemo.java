abstract class Employee {
    // Abstract method to calculate the amount paid to the employee
    public abstract double getAmount();
}

class WeeklyEmployee extends Employee {
    private int numberOfWeeks;
    private double totalWeeks;

    // Constructor
    public WeeklyEmployee(int numberOfWeeks, double totalWeeks) {
        this.numberOfWeeks = numberOfWeeks;
        this.totalWeeks = totalWeeks;
    }

    // Implementing abstract method
    @Override
    public double getAmount() {
        // Assuming a fixed payment per week for weekly employees
        double weeklyPayment = 500.0; // Change this value as needed
        return weeklyPayment * numberOfWeeks;
    }
}

class HourlyEmployee extends Employee {
    private int numberOfHours;
    private double totalHours;

    // Constructor
    public HourlyEmployee(int numberOfHours, double totalHours) {
        this.numberOfHours = numberOfHours;
        this.totalHours = totalHours;
    }

    // Implementing abstract method
    @Override
    public double getAmount() {
        // Assuming an hourly rate for hourly employees
        double hourlyRate = 15.0; // Change this value as needed
        return hourlyRate * numberOfHours;
    }
}

public class EmployeeDemo {
    public static void main(String[] args) {
        // Example usage
        WeeklyEmployee weeklyEmployee = new WeeklyEmployee(4, 10); // 4 weeks of work
        HourlyEmployee hourlyEmployee = new HourlyEmployee(30, 50); // 30 hours worked

        // Displaying the amount paid to each employee
        System.out.println("Weekly Employee - Amount: $" + weeklyEmployee.getAmount());
        System.out.println("Hourly Employee - Amount: $" + hourlyEmployee.getAmount());
    }
}
