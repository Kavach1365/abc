import java.util.*;

interface Vehicle
{
	String getCompany();
	String getModel();
	String getType();
	String getConsumption()
}

class TwoWheelers implements Vehicle
{
	private String Company,Model,Type;
	private double petrol=14,diesel=22,cng=18;

	public TwoWheelers(String Company,String Model,String Type)
	{
		this.Company=Company;
		this.Model=Model;
		this.Type=Type;
	}

	public String getCompany()
	{
		return Company;
	}
	public String getModel()
	{
		return Model;
	}
	public getType()
	{
		return Type;
	}

}