
import java.util.*;

interface Fraud {
    void taxChecker(double totalIncome, double totalExpenditure, double taxPaid) throws TaxFraudException;
    void taxPaid(double amountPaid);
    void homeExpenditure(double amount);
    void healthExpenditure(double amount);
    void vehicleExpenditure(double amount);
    void personalFamilyExpenditure(double amount);
    void miscellaneousExpenditure(double amount);
}

class TaxFraudException extends Exception {
    public TaxFraudException(String message) {
        super(message);
    }
}

class Tax implements Fraud {
    public  double totalIncome;
    public double totalExpenditure;
    public double taxPaid;

    public Tax(double totalIncome, double totalExpenditure, double taxPaid) {
        this.totalIncome = totalIncome;
        this.totalExpenditure = totalExpenditure;
        this.taxPaid = taxPaid;
    }

    @Override
    public void taxChecker(double totalIncome, double totalExpenditure, double taxPaid) throws TaxFraudException {
        double expectedTax = 0.1 * (totalIncome - totalExpenditure);
        System.out.println(taxPaid+" "+expectedTax);
        if (taxPaid < expectedTax) {
            throw new TaxFraudException("Tax fraud detected! You need to pay at least $" + expectedTax);
        }
    }

    @Override
    public void taxPaid(double amountPaid) {
        System.out.println("Tax paid: $" + amountPaid);
    }

    @Override
    public void homeExpenditure(double amount) {
        totalExpenditure += amount;
    }

    @Override
    public void healthExpenditure(double amount) {
        totalExpenditure += amount;
    }

    @Override
    public void vehicleExpenditure(double amount) {
        totalExpenditure += amount;
    }

    @Override
    public void personalFamilyExpenditure(double amount) {
        totalExpenditure += amount;
    }

    @Override
    public void miscellaneousExpenditure(double amount) {
        totalExpenditure += amount;
    }
}

// Main class to demonstrate the tax fraud detection system
public class TaxFraud {
    public static void main(String[] args) {
        Tax taxpayer = new Tax(50000.0, 20000.0, 800.0);

        try {
            taxpayer.homeExpenditure(10000.0);
            taxpayer.healthExpenditure(5000.0);
            taxpayer.vehicleExpenditure(2000.0);
            taxpayer.personalFamilyExpenditure(3000.0);
            taxpayer.miscellaneousExpenditure(1000.0);

            taxpayer.taxChecker(taxpayer.totalIncome, taxpayer.totalExpenditure, taxpayer.taxPaid);
        } catch (TaxFraudException e) {
            System.out.println(e.getMessage());
        }
    }
}
