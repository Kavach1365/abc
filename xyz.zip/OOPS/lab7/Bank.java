package bank;

public class Bank implements BankSystem
{
	public Map<String,String>  mp;

	public double balance;
	public String Username,password;

	public Bank(String Username,String password,double balance)
	{
		mp=new HashMap<>();
		this.Username=user;
		this.password=pass;
		this.balance=balance;
	}
    
    public boolean credentialsCheck(String user,String pass)
    {
    	return user.equals(Username) && pass.equals(password);
    }

    public void debit(double amount) throws InsufficientBalanceException
    {
    	if(balance<amount)
    		throw new InsufficientBalanceException("Insufficient balance. Transaction failed.");
    	balance-=amount;
    	displayBalance();
    }

    public void credit(double amount)
    {
    	balance+=amount;
    	displayBalance();
    }

    public void displayBalance(){
    	System.out.println("Available Balance: "+balance);
    }

}