import java.util.*;

class ArrayIndexOutOfBoundsException extends Exception{
	public ArrayIndexOutOfBoundsException(String s)
	{
		super(s);
	}
}

public class Bean
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);

		// int[] arr=new int[]{0,2,3,4,5};

		try
		{
			fun();

		}
		// catch(ArithmeticException a)
		// {
		// 	System.out.println(a);
		// }
		// catch(ArrayIndexOutOfBoundsException e)
		// {
		// 	System.out.println(e);
		// }
		// catch(NullPointerException s)
		// {
		// 	System.out.println(s);
		// }
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
	}

	public static void fun() throws ArrayIndexOutOfBoundsException
	{
		int[] arr=new int[]{1,2,3};
        if(arr.length>1)
        	throw new ArrayIndexOutOfBoundsException("Error"+5);
	}
}