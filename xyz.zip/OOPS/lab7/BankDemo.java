//package bank;
import java.util.*;

class InsufficientBalanceException extends Exception{
    InsufficientBalanceException(String msg){
        super(msg);
    }
}

interface BankSystem
{
	abstract public boolean credentialsCheck(String Username,String password);
	abstract public void credit(double amount);
	abstract public void debit(double amount) throws InsufficientBalanceException;
	abstract public void displayBalance();
	//abstract public void exit();
}

class Bank implements BankSystem
{
	public double balance;
	public String Username,password;

	public Bank(String Username,String password,double balance)
	{
		this.Username=Username;
		this.password=password;
		this.balance=balance;
	}
    
    public boolean credentialsCheck(String user,String pass)
    {
    	return user.equals(Username) && pass.equals(password);
    }

    public void debit(double amount) throws InsufficientBalanceException
    {
    	if(balance<amount)
    		throw new InsufficientBalanceException("Insufficient balance.Debit failed!!");
    	balance-=amount;
    	displayBalance();
    }

    public void credit(double amount)
    {
    	balance+=amount;
    	displayBalance();
    }

    public void displayBalance(){
    	System.out.println("Available Balance: "+balance);
    }

}


public class BankDemo
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
        
        Map<String,Bank> mp=new HashMap<>();

        mp.put("user1",new Bank("user1","pass1",1000.0));
        mp.put("user2",new Bank("user2","pass2",2000.0));
        mp.put("user3",new Bank("user3","pass3",3000.0));

        String username,password;
        try
        {
            int exit=1;
            while(exit==1){

            System.out.print("Enter username : ");
            username=sc.next();
            System.out.print("Enter password : ");
            password=sc.next();
            
            if(mp.containsKey(username))
            {
            if(mp.get(username).credentialsCheck(username,password))
            {
                mp.get(username).credit(1000.0);
                mp.get(username).debit(15000.0);
            }
             else
                System.out.println("Invalid password!!");
            }

            else
            	System.out.println("Invalid username!!");
          }
        }
        catch (InsufficientBalanceException e) {
            System.out.println(e.getMessage());
        }
	}
}