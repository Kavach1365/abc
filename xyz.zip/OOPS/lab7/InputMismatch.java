import java.util.*;

public class InputMismatch
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
        double ip=0;

		try{
			System.out.print("Enter a Number: ");
			ip=sc.nextDouble();
		}
		catch(InputMismatchException e){
            System.out.println(e);
		}
		finally{
			System.out.println("You entered i/p "+ip);
		}
	}
}