import java.util.*;

import bank.Bank;

public class BankDemo
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
        
        Bank b1=new Bank("user1","pass1",1000.0);
        String username,password;
        try
        {
            System.out.println("Enter username : ");
            username=sc.next();
            System.out.println("Enter password : ");
            password=sc.next();

            if(b1.credentialsCheck(username,password))
            {
                b1.credit(1000.0);
                b1.debit(15000.0);
            }
            else
            	System.out.println("Invalid Credentials!!");
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
	}
}