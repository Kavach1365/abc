//A simple frame
import javax .swing.*;
class swing1 {
    public static void main(String args[])  {
          //create the frame with title
             JFrame obj=new JFrame(" My frame");
       
          obj.setSize(600,600);
      
       //display the frame
       obj.setVisible(true);
    }
}