public class SuggestCar
{
    public static void main(String[] args) 
    {
        Car car1 = new Car("Toyota", 30.0, 65.0, "Silver");
        Car car2 = new Car("Honda", 35.0, 60.0, "Blue");
        Car car3 = new Car("Ford", 25.0, 70.0, "Red");
    }
}
