import java.util.*;

public class TV{
   
    public int channel,volume;
    public boolean on;
    
    public void TV()
    {
      this.channel=01;
      this.volume=3;
      this.on=false;
    }
    
    public void turnOn()
    {
      on=true;
      System.out.println("TV : ON");
    }
    public void turnOff()
    {
      on=false;
      System.out.println("TV : OFF");
    }
    
    public void setChannel(int newch)
    {
      channel=newch;
      System.out.println("current channel :"+channel);
    }
    public void setVolume(int newvol)
    {
      volume=newvol;
      System.out.println("curr volume :"+volume);
    }
    
    public void channelUp()
    {
      channel++;
      System.out.println("Channel :"+channel);
    }
    public void channelDown()
    {
      channel--;
      System.out.println("Channel :"+channel);
    }
    
    public void volumeUp()
    {
      volume++;
      System.out.println("Volume :"+volume);
    }
    public void volumeDown()
    {
      volume--;
      System.out.println("Volume :"+volume);
    }
    
    public static void main(String args[])
    {
       Scanner sc=new Scanner(System.in);
       TV remote=new TV();
       
       int cont=1;
       while(cont==1)
       {
         System.out.println("Select the operation:\n1.turnOn\n2.turnOff\n3.setChannel\n4.setVolume\n5.channelUp\n6.channelDown\n7.VolumeUp\n8.VolumeDown");
       int choice=sc.nextInt();
       switch(choice)
       { 
       case 1: remote.turnOn();break;
       case 2: remote.turnOff();cont=0;break;
       case 3: remote.setChannel(20);break;
       case 4: remote.setVolume(10);break;
       case 5: remote.channelUp();break;
       case 6: remote.channelDown();break;
       case 7: remote.volumeUp();break;
       case 8: remote.volumeDown();break;
       default: break;
       }
     }
   }
}
    
