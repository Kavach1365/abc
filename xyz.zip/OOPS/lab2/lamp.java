import java.util.*;

class Lamp
{
    private boolean isOn;
    private String lampType;
    
    public Lamp(String lamp,boolean isOn)
    {
        this.lampType=lamp;
        this.isOn=isOn;
    }
    
    void turnOff()
    {
        System.out.println("Current state: "+isOn);
        isOn=false;
        System.out.println(lampType+" is OFF");
    }
    
    void turnOn()
    {
        System.out.println("Current state: "+isOn);
        isOn=true;
        System.out.println(lampType+" is ON");
    }
    
}

public class lamp
{   
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
    
        Lamp led=new Lamp("led",true);
        Lamp  halogen=new Lamp("halogen",false);
        
        int cont=1; 
        while(cont==1)
        {
           System.out.println("Select the lamp:\n1.Halogen\n2.Led");
           int ch1=sc.nextInt();
           System.out.println("Select the operation:\n1.turnOn\n2.turnOff");
           int ch2=sc.nextInt();
           
           if(ch1==1)
           {
             
             if(ch2==1)
                halogen.turnOn();
             else
                halogen.turnOff();
           }
          else
           {
            
             if(ch2==1)
                led.turnOn();
             else
                led.turnOff();
           }
          System.out.print("Continue? ");
          cont=sc.nextInt();   
       }
   }
}
