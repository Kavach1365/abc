import java.util.*;
class try_catch
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int k;
		try
		{
			k=sc.nextInt();
		}
		catch(InputMismatchException e)  //pass the object which was thown by JRE,(JRE do this to protect syst. frm crash during runtime errors)...here obj is e of type InputMismatchException(this type obj thown that we are passing it to obj e of catch)
		{
		System.out.println("INvalid...");
		}	
	}
}
