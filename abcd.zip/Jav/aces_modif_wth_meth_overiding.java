import java.lang.*;
import java.util.*;

public class A{

void msg(){
System.out.println("hi from AAA");
}

}

class aces_modif_wth_meth_overiding extends A{
public static void main(String args[]){
void msg(){
System.out.println("HIII from main");
}
A obj=new A();
obj.msg();
}
}
