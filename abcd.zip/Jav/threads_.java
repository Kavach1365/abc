import java.util.*;

class thread1 extends Thread
{
	public void run()
	{
		for(int i=0;i<5;i++)
		{
		System.out.println("i="+i);
		}
				System.out.println("exiting thread1...");
	}
}
class thread2 extends Thread
{
	public void run()
	{
		for(int j=0;j<5;j++)
		{
		System.out.println("j="+j);
		}
				System.out.println("exiting thread2...");
	}
}
class thread3 extends Thread
{
	public void run()
	{
		for(int k=0;k<5;k++)
		{
		System.out.println("k="+k);
		}
				System.out.println("exiting thread3...");
	}
}

public class threads_
{
	public static void main(String args[])
	{
	thread1 t1=new thread1();
	thread2 t2=new thread2();
	thread3 t3=new thread3();
	t1.start();
	t2.start();
	t3.start();
			System.out.println("exiting main...");
	}
		

}
