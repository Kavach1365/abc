import java.util.*;


class  lab38
{
	public static void main(String a[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string: ");
		String s=sc.next();
		System.out.println("Enter substring: ");
		String sub=sc.next();
		System.out.println(s.indexOf(sub));
		
		System.out.println("Enter string: ");
		String s2=sc.next();
		System.out.println("Enter substring: ");
		String sub2=sc.next();
		int n1=s.length(),n2=sub.length();
		
		for(int i=0;i<n1-n2+1;i++)
		{
		if(s2.startsWith(sub2,i)) System.out.println("sub foundd");
		}
		
		
		
		
		
		
		
		
		
		
		
	}
	
}
