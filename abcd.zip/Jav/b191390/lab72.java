import java.util.*;
import lab72pack.bank;


public class lab72
{
	public static void main(String arg[])
	{
		bank u1=new bank("u1","123",100);
		//bank u2=new bank("u2","456",200);
		//bank u3=new bank("u3","xyz",500);
		int c=1,a;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter username and password to enter the system: ");
		String u=sc.next();			
		String p=sc.next();
		try{
		u1.credentialsCheck(u,p);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		while(c!=0)
		{
			
			System.out.println("Enter(1 to debit,2-credit,3-display balance,0-EXIT)");
			c=sc.nextInt();
			switch(c)
			{
				case 1:
				System.out.println("Enter amount to be debited: ");
				a=sc.nextInt();
				try{
				u1.debit(a);}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
				
				case 2:
				System.out.println("Enter amount to be credited: ");
				a=sc.nextInt();
				u1.credit(a);
				break;
				
				case 3:
				u1.displayBalance();
				break;
				
				case 0:
				c=0;
				u1.exit();
			}
			
		}
	}
}
