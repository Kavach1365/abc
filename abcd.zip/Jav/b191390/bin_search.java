import java.util.*;

public class bin_search
{
public static void main(String args[])
{
Scanner q=new Scanner(System.in);
System.out.print("Entern array size:");
int n=q.nextInt();
int a[]=new int[n];
for(int i=0;i<n;i++) a[i]=q.nextInt();

System.out.print("Entern search ele:");
int k=q.nextInt();
int low=0,high=n;



//main h=new main();
int r=bin(a,low,high,k);
System.out.println();
System.out.println("key found at index "+r);
}

public static int bin(int a[],int low,int high,int k)
{
if(low<high)
{
int mid=(low+high)/2;
if(a[mid]==k) return mid;
else if(k<a[mid]) return bin_search.bin(a,low,mid,k);
else return bin_search.bin(a,mid,high,k); 
}
else return -1;
}
}
