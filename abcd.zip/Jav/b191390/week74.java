import java.util.*;


   class week74{
   	int a,b;
   	System.out.println("enter a b values");
          try{
          System.out.println("a/b="+(a/b));
          
          }
          
           catch(exception e){
           System.out.println(e);
           }
           
           int a[]=new int[10];
           
          try{
          System.out.println(a[100]);
          }
        
           catch(exception e){
           System.out.println(e);
           }
   }
 
