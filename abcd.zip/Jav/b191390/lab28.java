import java.util.*;

class  lab38
{
	public static void main(String a[])
	{
		System.out.println("Enter string: ");
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		System.out.println("Enter substring: ");
		Scanner sc=new Scanner(System.in);
		String sub=sc.next();
		System.out.println(s.indexOf(sub));
	}
	
}
