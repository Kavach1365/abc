import dept.cse;
import dept.ece;
import dept.me;
import dept.ce;

class week6_22{
public static void main(String args[])
   {
   cse o=new cse();
   ece o1=new ece();
   me o2=new me();
   ce o3=new ce();
   o.display_sub();
   o1.display_sub();
   o2.display_sub();
   o3.display_sub();
   }
}
