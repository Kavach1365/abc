import java.util.*;

class shape
{
	 double getArea(double r)
	{
		return 0;
	}
	
	double getPerimeter(double a)//static
	{
		return 0;
	}
}

class circle extends shape
{
	double r;

	double getArea(double r)
	{
		return (22f/7f)*r*r;
	}
	double getPerimeter(double r)
	{
		return 2*(22f/7f)*r;
	}

}

class square extends shape
{
	double a;
	
	double getArea(double a)
	{
	return a*a;
	}
	double getPerimeter(double a)//static
	{
		return 4*a;
	}
	
}
class lab41
{
	public static void main(String args[])
	{
		shape s=new shape();
		shape s2=new circle();
		shape s3=new square();	
		System.out.println("defualt shape area="+s.getArea(5.5f));
		System.out.println("cirle area="+s2.getArea(5.5f));
		System.out.println("square area"+s3.getArea(5.5f));
		System.out.println("default shape perimeter="+s.getPerimeter(5.5f));
		//If getPerimeter method is static typecasting from sub to super will not work during runtime..coz object creation is done at compile time...so,circle or sqaure obj wont't ovveride the method..so ouput is 0.0,0.0,0.0
		System.out.println("cirlce perimeter="+s2.getPerimeter(5.5f));
		System.out.println("square perimter="+s3.getPerimeter(5.5f));
		Scanner sc=new Scanner(System.in);
		int e=1;
		do
		{
			int a,b;
			System.out.println("Enter 1 to create circle,2 to create sqare:");
			int x=sc.nextInt();
			if(x==1)
			{	
				System.out.println("Enter radious of cirlce and (1-area,2-perimeter,3-both): ");
				double r=sc.nextDouble();
				shape s4=new circle();
				int y=sc.nextInt();
				switch(y)
				{
				case 1:System.out.println("Area of circle="+s4.getArea(r));
				break;
				case 2:System.out.println("Perimeter of circle="+s4.getPerimeter(r));
				break;
				case 3:
				System.out.println("Area of circle="+s4.getArea(r));
				System.out.println("Perimeter of circle="+s4.getPerimeter(r));
				}
			}
			if(x==2)
			{	
				System.out.println("Enter side of square and (1-area,2-perimeter,3-both): ");
				double r=sc.nextDouble();
				shape s5=new square();
				int y=sc.nextInt();
				switch(y)
				{
				case 1:System.out.println("Area of square="+s5.getArea(r));
				break;
				case 2:System.out.println("Perimeter of square="+s5.getPerimeter(r));
				break;
				case 3:
				System.out.println("Area of square="+s5.getArea(r));
				System.out.println("Perimeterof square="+s5.getPerimeter(r));
				}
			}
			System.out.println("Enter 0 to exit,1-to continue:");
			e=sc.nextInt();
		
		}while(e!=0);
		
		
		
	}
}

