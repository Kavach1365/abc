package bank;

// Interface defining the basic functionalities
public interface BankOperations {
    void credentialsCheck(String username, String password);
    void credit(double amount);
    void debit(double amount) throws InsufficientFundsException;
    void displayBalance();
    void exit();
}

// Custom exception for insufficient funds during a debit operation
class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

// Example implementation of the BankOperations interface
public class BankSystem implements BankOperations {
    private String username;
    private String password;
    private double balance;

    // Constructor to initialize the account with username, password, and initial balance
    public BankSystem(String username, String password, double initialBalance) {
        this.username = username;
        this.password = password;
        this.balance = initialBalance;
    }

    @Override
    public void credentialsCheck(String username, String password) {
        if (!this.username.equals(username) || !this.password.equals(password)) {
            System.out.println("Error: Username and password mismatch!");
        } else {
            System.out.println("Credentials verified successfully!");
        }
    }

    @Override
    public void credit(double amount) {
        balance += amount;
        System.out.println(amount + " credited successfully.");
    }

    @Override
    public void debit(double amount) throws InsufficientFundsException {
        if (amount > balance) {
            throw new InsufficientFundsException("Error: Debit amount exceeds available balance!");
        } else {
            balance -= amount;
            System.out.println(amount + " debited successfully.");
        }
    }

    @Override
    public void displayBalance() {
        System.out.println("Current Balance: " + balance);
    }

    @Override
    public void exit() {
        System.out.println("Exiting the bank system. Thank you!");
        // Perform any necessary cleanup or exit actions here
    }
}

// Main class to demonstrate the functionality
public class BankManagementSystem {
    public static void main(String[] args) {
        BankOperations bank = new BankSystem("user123", "password123", 1000.0);

        // Example usage
        bank.credentialsCheck("user123", "password123");
        bank.credit(500.0);
        bank.displayBalance();

        try {
            bank.debit(200.0);
            bank.debit(2000.0); // This will throw InsufficientFundsException
        } catch (InsufficientFundsException e) {
            System.out.println(e.getMessage());
        }

        bank.displayBalance();
        bank.exit();
    }
}

