import java.util.*;

interface vehicle 
{
	abstract String getcompany();
	abstract String getmodel();//2 for 2 wheeler
	abstract String gettype();// petrol.diesel,cng
	abstract double getconsumption(double dist);
}

class calc implements vehicle
{
	String comp,mod,type;
	//int fc;
	calc(String c,String m,String t)
	{comp=c; mod=m; type=t; }
	public String getcompany()
	{
		return comp;
	}
	public String getmodel()
	{
		return mod;
	}
	public String gettype()
	{
		return type;
	}
	public double getconsumption(double dist)
	{
		if(mod=="2" && type=="petrol")return dist/62f;
		else if (mod=="2" && type=="diesel") return dist/82f;
		else if(mod=="2" && type=="cng") return dist/72f;
		else if(type=="petrol") return dist/14f;
		else if(type=="diesel") return dist/22f;
		else return dist/18f;
	}
}


class lab53
{
	public static void main(String args[])
	{
		calc v1=new calc("royal","2","cng");
		System.out.println(v1.getconsumption(100)+"  liters consumed ");
			
	}
}
