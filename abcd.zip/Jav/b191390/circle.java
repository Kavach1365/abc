
package shapes;
class circle{
          
          void area(int a){
    System.out.println((Math.PI*a*a);
    }
    void peri(int a){
    System.out.println((Math.PI*2*a));
    }

      }
