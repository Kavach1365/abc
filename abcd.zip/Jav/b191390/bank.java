package lab72pack;


class InsufficientBalanceException extends Exception
{
	public InsufficientBalanceException(String message)
	{
		super(message);
	}
}

class username_or_passwordMismatchException extends Exception
{
	public username_or_passwordMismatchException(String message)
	{
		super(message);
	}
} 

public class bank implements lab72Intf
{
	 public String uname,password;
	 public int balance;
	
	
	public bank(String uname,String password, int balance)
	{
		this.uname=uname; 
		this.password=password;
		this .balance=balance;
	}
	
	
	@Override
	public void credentialsCheck(String u,String p) throws username_or_passwordMismatchException
	{
		if((this.uname==u && this.password!=p) || (this.uname!=u && this.password==p) || 			(this.uname!=u && this.password!=p))
		throw new username_or_passwordMismatchException("Username or password Exception...");
	}
	
	@Override	
	public void debit(int amount) throws InsufficientBalanceException
	{
		if(amount>balance)
		throw new InsufficientBalanceException("Error: Insufficient balance...");
		else 
		balance=balance-amount;
	}
	
	
	@Override	
	public void credit(int amount)
	{
		balance=balance+amount;
		System.out.println(amount+" credited successfully...");
	}
	@Override	
	public void displayBalance() {
        		System.out.println("Current Balance: " + balance);
   	 }
   	 
 	@Override  	 
	public void exit()
	{
		System.out.println("exiting....");	
	}
}
