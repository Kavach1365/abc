interface fare{

double getFare();
void getAmenities();

}



class transport implements fare{
String mode,type,n;
transport(String mode,String type){
this.mode=mode;
this.type=type;
this.n=n;
}

public double getFare(){
if(mode=="bus"){
  if(type=="ac") return(n*250);
  else if(type=="non ac") return(n*20);
  else if(type=="sleeper") return(n*100);
  else if(type=="semi sleeper") return(n*60)
  else return(n*7);
}
else if(mode=="train"){
if(type=="general") return(n*0.45);
else if(type=="sleeper") return(n*0.75);
else return(n*1.50);
}

else if(mode=="flight")
{
if(type=="business") return(n*5000);
else return(n*2000);
}
else return(n*1);
}
public void getamenities(){


if(mode=="bus"){
  if(type=="ac") System.out.println("food,tv");
  else if(type=="non ac") System.out.println("snacks");
  else if(type=="sleeper") System.out.println("fan,blanket");
  else if(type=="semi sleeper") System.out.println("charging ports");
  else System.out.println("seat");
}
else if(mode=="train"){
if(type=="general") System.out.println("snacks,cool drinks");
else if(type=="sleeper") System.out.println("fan,3 breadth seat,food");
else System.out.println("ac,food,tv");
}

else if(mode=="flight")
{
if(type=="business") return(n*5000);
else System.out.println("tab,books,food,wine,air host service");
}
else System.out.println("food,airhost service");

}


}
