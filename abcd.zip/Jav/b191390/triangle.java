package shapes;

class traingle{
      
      void area(int a,int b,int c,int h){
    System.out.println(((b*h)/2));
    }
    void peri(int a){
    System.out.println((a+b+c));
    }
      
      }   
