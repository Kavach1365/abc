import java.util.*;


class Emp
{
	int eid,eage,esal;
	String ename,egen,edesg,eaddr;
	Emp(int id,int age,int sal,String name,String gen,String desg,String addr)
	{
		this.eid=id;this.eage=age; this.esal=sal;
		this.ename=name; this.egen=gen; this.edesg=desg; this.eaddr=addr;
	}

}


class lab3_10
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter no.of employees: ");
		int n=sc.nextInt();	
		Emp e[]=new Emp[n];
		for(int i=0;i<n;i++)
		{
		System.out.println("Enter emp details(id,name,age,gender,designation,sal,address): ");
		int id=sc.nextInt();
		String nm=sc.next();
		int a=sc.nextInt();
		String g=sc.next();
		String d=sc.next();
		int s=sc.nextInt();
		String ad=sc.next();
		e[i]=new Emp(id,a,s,nm,g,d,ad);
		}
		
		System.out.println("\nEnter emp id: ");
		int idd=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			if(e[i].id==idd) System.out.println("Details are name: "+e[]);
		}
	
	}
}
