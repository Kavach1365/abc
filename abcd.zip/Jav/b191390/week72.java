import java.util.*;


  class week72{
  	public static void main(String args[])
  	{
  	int n,,x;
  	Double amount;
  	Scanner sc=new Scanner(System.in);
  	//HashMao<String, String> hm=new HashMap<String, String>();
  	System.out.println("enter no of users");
  	n=sc.nextInt();
  	System.out.println("enter username and password");
  	String nam= nextLine();
  	String pass= nextLine();
  	class_name o= new class_name(nam,pass);
  	System.out.println("enter no of 1,2,3,4,5 for check,c,d,dis,e");
  	switch(x){
  	case 1: System.out.println("enter username and password");
  	          String nam= nextLine();
  		String pass= nextLine();
  	          System.out.println(credentialsCheck(name,pass));
  	          break;
  	case 2: System.out.println("enter amount");
  	          String amount= nextDouble();
  	          credit(amount);
  	          break;
  	          
  	case 3: System.out.println("enter amount");
  	          String amount= nextDouble();
  	          debit(amount);
  	      
          case 4: System.out.println(displayBalance());
  	          break;      
  	  	
  	}
  	
 
  	}
  
  }
