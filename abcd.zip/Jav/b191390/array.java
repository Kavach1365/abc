import java.util.*;

public class array
{
public static void main(String args[])
{
Scanner q=new Scanner(System.in);
System.out.print("Enter array size: ");
int n=q.nextInt();

int a[]=new int[n];
for(int i=0;i<n;i++) a[i]=q.nextInt();
System.out.println("Elements are:");
for(int i=0;i<n;i++) System.out.print(a[i]+" ");
int min=a[0],max=a[0];
for(int i=0;i<n;i++)
{
if(a[i]<min) min=a[i];
if(a[i]>max) max=a[i];
}
System.out.println("MIn="+min+"  Max="+max);
}
}
