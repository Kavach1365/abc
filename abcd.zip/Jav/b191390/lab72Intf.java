package lab72pack;

import java.util.*;




public interface lab72Intf
{
	void credentialsCheck(String username,String password) throws username_or_passwordMismatchException;
	void credit(int x);
	void debit(int x) throws InsufficientBalanceException;
	void displayBalance();
	void exit();
}
