import java.util.*;


class Monster
{
	String attack()
	{
	return "Attacks ";
	}
}

class FireMonster extends Monster
{
	String attack()
	{
	return "Attacks with fire";
	}
}

class WaterMonster extends Monster
{
	String attack()
	{
	return "Attacks with water";
	}
}

class StoneMonster extends Monster
{
	String attack()
	{
	return "Attacks with stones";
	}
}
public class lab43{
public static void main(String args[])
{
	Monster m1,m2,m3;
	 m1=new FireMonster();
	 m2=new WaterMonster();
	 m3=new StoneMonster();
	System.out.println(m1.attack());
	System.out.println(m2.attack());
	System.out.println(m3.attack());
	
}
}
