

class monst{
String name;
String attack();

}

class firemonster{
String attack(){
return "fire";
}
}

class watermonster{
String attack(){
return "water";
}
}

class stonemonster{
String attack(){
return "stone";
}
}

class game{




}
