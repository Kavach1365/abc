

 interface vehcile{
 
 void getCompany();
 void getModel(); 
 void getType();
 double getConsumption();
 
 }
 
 class wheeler2 implements vehcile{
 
 String Company,Model,Type;
 int dist;
 public void getCompany(){
 System.out.println("w2 comapny:"+Company);
 
 
 }
 wheeler2(String Company,String Model,String Type,int dist){
 this.Company=Company;
 this.Model=Model;
 this.Type=Type;
 this.dist=dist;
 
 }
 public void getModel(){
 System.out.println("model:"+Model);
 
 
 }
 
 public void getType(){
 System.out.println("Type:"+Type);
 
 
 }
 public double getConsumption()
 {
 
 if(Model=="2" && Type=="petrol")return dist/62;
		else if (Model=="2" && Type=="diesel") return dist/82;
		else if(Model=="2" && Type=="cng") return dist/72f;
		else if(Type=="petrol") return dist/14;
		else if(Type=="diesel") return dist/22f;
		else return dist/18f;
 
 
 
 }
  
 }
 
 
 class week_53{
 public static void main(String args[])
  {
  wheeler2 b1=new wheeler2("bajaj","2","petrol",1000);
  wheeler2 c1=new wheeler2("ford","4","cng",20000);
  b1.getCompany();
 b1.getModel(); 
 b1.getType();
 System.out.println(b1.getConsumption());
  
  
  c1.getCompany();
 c1.getModel(); 
 c1.getType();
 System.out.println(c1.getConsumption());
  
  } 
 
 }
