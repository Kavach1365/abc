package dept;

 interface demo{
 void display_sub();
 
 }
 



 public class cse implements demo{
 public void display_sub(){
 System.out.println("c,os,daa,dsa,oops,linear algebra,coa,");
 }
 }
