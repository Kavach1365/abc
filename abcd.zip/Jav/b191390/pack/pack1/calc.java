package calculator;

import java.util.*;

public interface calc
{
	public float add(float a,float b);
	public float subtract(float a,float b);
	public float multiply(float a,float b);
	public float divide(float a,float b);
}


