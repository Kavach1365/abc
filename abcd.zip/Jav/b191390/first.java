import java.util.*;

public class first
{
public static void main(String args[])
{
System.out.print("Entern a num:");
Scanner q=new Scanner(System.in);
int x=q.nextInt();
System.out.println("the number entered is :"+x);

for(int i=1;i<x;i++)
{
if(x%i==0)
{
int f=0;
	for(int j=2;j<i;j++)
	{
	if(i%j==0) break;
	else f=1;
	}
	
	if(f==1) System.out.print(i+" ");
}
}
}
}

