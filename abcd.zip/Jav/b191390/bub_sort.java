import java.util.*;

public class bub_sort
{
public static void main(String args[])
{
Scanner q=new Scanner(System.in);

System.out.print("Entern array size:");
int n=q.nextInt();

int a[]=new int[n];
for(int i=0;i<n;i++) a[i]=q.nextInt();
System.out.println("Elements are:");
for(int i=0;i<n;i++) System.out.print(a[i]+" ");

for(int i=0;i<n-1;i++)
{
for(int j=0;j<n-i-1;j++)
{
if(a[j+1]<a[j]) {
		int x;
		x=a[j];
		a[j]=a[j+1];
		a[j+1]=x;
		}
}
}
System.out.println();
System.out.print("After sorting Elements are:");
for(int i=0;i<n;i++) System.out.print(a[i]+" ");


}}
