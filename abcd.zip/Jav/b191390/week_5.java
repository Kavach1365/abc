import java.util.*;

abstract class shape_2d{
abstract void getarea(double a);


}

abstract class shape_3d{

abstract void getvolume(double a);


}


class square extends shape_2d{
 
void getarea(double a){
System.out.println("area of square:"+(a*a));
}}


class cube extends shape_3d{
void getvolume(double a){
System.out.println("volume of cube:"+(a*a*a));
}
}


class circle extends shape_2d{

void getarea(double a)
{
System.out.println("area of circle:"+(Math.PI*a*a));

}}


class sphere extends shape_3d{
void getvolume(double a){
System.out.println("volume of sphere"+((4/3)*(Math.PI*a*a*a)));
}
}

class week_5{

public static void main(String args[]){
System.out.println("enter the value of side of square and radius of the circle");
double a,r;
Scanner sc=new Scanner(System.in);
a=sc.nextDouble();
r=sc.nextDouble();
square s1=new square();
s1.getarea(a);

cube cu=new cube();
cu.getvolume(a);

circle c1=new circle();
c1.getarea(r);

sphere sp1=new sphere();
sp1.getvolume(r);

}
}

