package calculator;
 
  interface calsi{
  abstract double add(double a,double b);
  abstract double sub(double a,double b);
  abstract double div(double a,double b);
  abstract double mul(double a,double b);
  abstract double mod(double a,double b);
  }
  
  class operation implements calsi{
     public double add(double a,double b){
     return a+b;
     }
     
     public double sub(double a,double b){
     return a-b;
     }
     
     public double mul(double a,double b){
     return a*b;
     }
     
     public double div(double a,double b){
     return a/b;
     }
     
    public double mod(double a,double b){
     return a%b;
     }
  
  }
  
  
