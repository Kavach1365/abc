import java.util.*;

class Car{
String company,color;
private double speed,mileage;
Car()
{
company="mercedes";
color="black";
speed=180;
mileage=25;
}

Car(String com,String clr,double s,double m)
{
company=com; color=clr; speed=s; mileage=m;
}

double getMileage(){return mileage;}
double getSpeed(){return speed;}
}

class lab24{
public static void main(String args[]){
Car c1,c2,c3;
c1=new Car("Ford","blue",150,18);
c2=new Car("Toyota","red",140,20);
c3=new Car("volkswagon",130,16);


}

}
