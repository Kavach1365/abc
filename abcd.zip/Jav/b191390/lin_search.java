import java.util.*;

class lin_search{
public static void main(String args[]){
System.out.println("enter array size: ");
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int x[]=new int[n];
for(int i=0;i<n;i++)
x[i]=sc.nextInt();


System.out.print("enter key to search: ");
int key=sc.nextInt();

for(int i=0;i<n;i++) if(key==x[i]) {System.out.println(key+" found at index "+i); break;}


}
}
