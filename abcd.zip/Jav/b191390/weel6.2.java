package dept;

 interface demo{
 void display_sub();
 
 }
 
 
 


