abstract class employee{
abstract void getamount(int a);

}

class weekly extends employee{// per 1 week 8000
void getamount(int n){
System.out.println("for "+n+" weeks amount paid is: "+(n*8000));
}
}

class hourly extends employee{// per 1 week 200
void getamount(int n){
System.out.println("for "+n+" hours amount paid is: "+(n*200));
}
}

class week_5_2{
public static void main(String args[])
  {
  weekly e1= new weekly();
  e1.getamount(10);
  
  hourly e2= new hourly();
  e2.getamount(30);
  
  
  }
}
