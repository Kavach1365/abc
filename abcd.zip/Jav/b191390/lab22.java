import java.util.*;

class Lamp{
boolean ison;
String lampType;
Lamp(boolean ison){
this.ison=ison;
}

void checkStatus()
{
if(this.ison) System.out.println("This "+lampType+" Light is on");
else System.out.println("This "+lampType+" light is off");
}
void change()
{
if(ison) {ison=false; System.out.println("this "+lampType+" is turned off");}
else {ison=true; System.out.println("this "+lampType+" is turned on");}
}

}

class lab22{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);

System.out.println("enter inial state of lamp(0 for off,1 for on): ");
int st=sc.nextInt();
boolean k=(st==0)?false:true;
Lamp l1=new Lamp(k);
System.out.println("enter lamp type: ");
l1.lampType=sc.next();

l1.checkStatus();
l1.change();
l1.checkStatus();




}

}
