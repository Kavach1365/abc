 import java.util.*;

  class week71{
  
  public static void main(String args[])
    { double a;
    System.out.println("enter any integer");
    Scanner sc=new Scanner(System.in);
    try{
     a=sc.nextInt();
    }
    
    catch(Exception e)
    {
    System.out.println("you have entered non numeric which leads to ::"+e);
    }
    
    }
  
  }
