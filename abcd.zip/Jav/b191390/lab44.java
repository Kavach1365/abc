import java.util.*;

class vehicle
{
	String company,model;
	int mileage,fuelcapa;
	vehicle(String c,String m,int mil,int fc)
	{
	company=c; model=m; mileage=mil; fuelcapa=fc;
	}
}

class two_wheeler extends vehicle
{
	String frontbreak,rearbreak,tyre_type,head_lamp,user_reviews;
	two_wheeler(String c,String m,int mil,int fc,String fb,String rr,String tt,String hl,String ur)
	{
	super(c,m,mil,fc);
	frontbreak=fb; rearbreak=rr; tyre_type=tt; head_lamp=hl; user_reviews=ur;
	}
}

class four_wheeler extends vehicle
{
	String ac,air_bag,power_steering,wiper;
	four_wheeler(String c,String m,int mil,int fc,String ac,String ab,String ps,String w)
	{
	super(c,m,mil,fc);
	this.ac=ac; air_bag=ab; power_steering=ps; wiper=w;
	}
}

public class lab44
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter no of 2 wheelers: ");
		int t=sc.nextInt();
		two_wheeler tw[]=new two_wheeler[t]; 
		
		for(int i=0;i<t;i++)
		{
			System.out.println("Enter 2wheeler details(comp,modl,mil,fc,fb,rb,tt,hl,ur: )");
			String c,md,fb,rb,tt,hl,ur;
			int mil,fc;
			c=sc.next();
			md=sc.next();
			mil=sc.nextInt();
			fc=sc.nextInt();
			fb=sc.next();
			rb=sc.next();
			tt=sc.next();
			hl=sc.next();
			ur=sc.next();
			
			tw[i]=new two_wheeler(c,md,mil,fc,fb,rb,tt,hl,ur);
		}
		
		System.out.println("Enter no of 4 wheelers: ");
		int f=sc.nextInt();
		four_wheeler fw[]=new four_wheeler[f];
		for(int i=0;i<f;i++)
		{
			System.out.println("Enter 4wheeler details(comp,mdl,mil,fc,ac,airbg,powstr,wiper):");
			String c,md,ac,ab,ps,w;
			int mil,fc;
			c=sc.next();
			md=sc.next();
			mil=sc.nextInt();
			fc=sc.nextInt();
			ac=sc.next();
			ab=sc.next();
			ps=sc.next();
			w=sc.next();
			
			fw[i]=new four_wheeler(c,md,mil,fc,ac,ab,ps,w);
			
		}
		
		
		System.out.println("Enter vehicle type(2-for twowheeler,4-fourwheeler): ");
		int type=sc.nextInt();
		
		if(type==2)
		{
			System.out.println("Enter features you want(comp,modl,mil,fc,fb,rb,tt,hl,ur: ):: ");
			String c,md,fb,rb,tt,hl,ur;
			int mil,fc;
			c=sc.next();
			md=sc.next();
			mil=sc.nextInt();
			fc=sc.nextInt();
			fb=sc.next();
			rb=sc.next();
			tt=sc.next();
			hl=sc.next();
			ur=sc.next();
		}
		else if (type==4)
		{
			System.out.println("Enter 4wheeler features that you want(comp,mdl,mil,fc,ac,airbg,powstr,wiper):");
			String c,md,ac,ab,ps,w;
			int mil,fc;
			c=sc.next();
			md=sc.next();
			mil=sc.nextInt();
			fc=sc.nextInt();
			ac=sc.next();
			ab=sc.next();
			ps=sc.next();
			w=sc.next();
		}
		
		
		
	}
	
}
