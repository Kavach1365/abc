import java.util.*;


class person
{
	String name;
	String addr;
	person(String n,String a)
	{
		name=n; addr=a;
	}
	String getName()
	{
		return name;
	}
	String getAddress()
	{
		return addr;
	}
	
}

class student extends person
{
	int no_courses=0;
	Vector <String> courses=new Vector <String>();
	Vector <Integer> grades=new Vector <Integer>();
	student(String n,String a)
	{
	super(n,a);
	}
	void addCourseGrade(String c,int g)
	{
	no_courses++;
		if(no_courses<=30){
		courses.add(c);
		grades.add(g);
		System.out.println(courses);
		
		}
		else
		{
		System.out.println("A STUDENT CANT HAVE MORE THAN 30 COURSES...!!!");
		}
	}
	void printGrades()
	{
	for(int i=0;i<grades.size();i++)
	System.out.print(grades.get(i));
	System.out.println();
	}
	
	double AvgGd()
	{
		double sum=0.0;
		for(int i=0;i<grades.size();i++)
		{
			sum=sum+grades.get(i);
		}
		return sum/grades.size();
	
	}
}

class teacher extends person
{
	int no_courses=0;
	Vector <String> courses=new Vector <String>();
	teacher(String n,String a)
	{
	super(n,a);
	}
	boolean addCourse(String c)
	{
	no_courses++;
		if(no_courses<=5){
		if(courses.contains(c))
		return false;
		else
		{
		courses.add(c);
		return true;
		}
		}
		else
		{
		System.out.println("A TEACHER CANT TEACH MORE THAN 5 COURSES...!!!");
		return false;
		}
	}
	
	boolean removeCourse(String c)
	{
		if(courses.contains(c))
		{
			courses.remove(c);
			return true;
		}
		else
		return false;
	}
	
}


class lab42
{
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter no.of students: ");
	int sn=sc.nextInt();
	
	
	for(int i=0;i<sn;i++)
	{
	System.out.println("Enter student name,address: ");
	String n,a;
	n=sc.next();
	a=sc.next();
	student s1=new student(n,a);
	int e=1;
	do{
		System.out.print("Enter course,grade to add: ");
		String c;
		int g;
		c=sc.next();
		g=sc.nextInt();
		s1.addCourseGrade(c,g);
		System.out.print("Do u wanna add one more course(enter 0-exit, 1-continue): ");
		e=sc.nextInt();
		
	
		}while(e!=0);
	
	
	}
	
	System.out.println("Enter no.of teachers: ");
	int tn=sc.nextInt();
	
	
	for(int i=0;i<tn;i++)
	{
	System.out.println("Enter teacher name,address: ");
	String n,a;
	n=sc.next();
	a=sc.next();
	teacher t1=new teacher(n,a);
	int e=1;
	do{
		System.out.print("Enter course to add: ");
		String c;
		c=sc.next();
		t1.addCourse(c);
		System.out.print("Do u wanna add one more course(enter 0-exit, 1-continue): ");
		e=sc.nextInt();
		
	
		}while(e!=0);
	
	
	}
	
	
	
	}
}


