package shapes;

public class square{
    void area(int a){
    System.out.println((a*a));
    }
    void peri(int a){
    System.out.println((4*a));
    }
   }
