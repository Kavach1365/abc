import java.util.*;

class lab39
{
	public static void main(String a[])
	{
	System.out.println("Enter string: ");
	Scanner sc=new Scanner(System.in);
	String s=sc.next();
	s=s.toUpperCase();
	System.out.println("updated string: "+s);
	s=s.toLowerCase();
	System.out.println("updated string: "+s);	
	}

}
