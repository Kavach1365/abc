import java.util.*;

class account
{
	String bname,brname,aname,ano,aadr;
	double bal;
	
	 account(String bn,String brn,String an,String ano,String aa,double b)
	 {
	 	bname=bn; brname=brn; aname=an; this.ano=ano; aadr=aa; bal=b;
	 }
	 
	 void credit(double b)
	 {
	 	bal=bal+b;
	 }
	 void debit(double b)
	 {
	 	if(b<bal)
	 	bal=bal-b;
	 	else 
	 	System.out.println("Debit amount exceeded account balance...");
	 }
	 double getbalance()
	 {
	 	return bal;
	 }
	 
}


class user
{
	String br_name,act_no;
	
}

class lab45
{
	public static void main(String args[])
	{
	
	}
}
