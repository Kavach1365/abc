package dept;

 interface demo{
 void display_sub();
 
 }
 
 public class ce implements demo{
 public void display_sub(){
 System.out.println("linear algrbra,grachics,autocard");
 }
 }
