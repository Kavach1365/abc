import java.util.*;

class lab31
{
	public static void main(String a[])
	{
	//System.out.printf("%d %d %d",'a','A','0'); 97 68 45 ascii
	Scanner sc=new Scanner(System.in);
	System.out.printf("Enter string1: ");
	String s1=sc.next();
	System.out.printf("Enter string2: ");
	String s2=sc.next();
	System.out.println("\n1>> compareTo=="+s1.compareTo(s2));
	System.out.println("\n2>> equals=="+s1.equals(s2));
	System.out.println("equalsIgnoreCase=="+s1.equalsIgnoreCase(s2));
	
	System.out.println("\n3>> Enter char to search in string1: ");
	char c='k';
	int cnt=0;
	for(int i=0;i<s1.length();i++) 
	{
	if(s1.charAt(i)==c) cnt++;
	}
	//long cnt=s1.chars().filter(ch->ch==c).count(); 
	System.out.println("Total no.of occurences of char "+c+" in string "+s1+" is :"+cnt);
	
	System.out.println("\n4>> concatanating s1 and s2== "+s1+s2);
	System.out.println("concatanating s1 and s2== "+s1.concat(s2));	
	}

}
