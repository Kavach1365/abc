import java.util.*;


interface fare
{
	abstract int getfare();
	abstract String getamenities();
}

class c implements fare
{
	c()
	{
			
	}
}

class lab54
{
	public static void main(Stirng arrgs[])
	{
		
	}
}
