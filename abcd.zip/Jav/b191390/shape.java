import java.util.*;

class area{
 void get_area(int a){
System.out.println("area of square:"+(a*a));
 
 }
 
 void get_area(double r){
 System.out.println("area of circle"+Math.PI*r*r);
 
 }
 void get_area(int l,int b){
 System.out.println("area of rectangle"+(l*b));
 
 }
 
 void get_peri(int a){
 System.out.println("perimeter of square"+(4*a));
 }
 
 void get_peri(double r){
 System.out.println("perimeter of circle"+(2*Math.PI*r));}


 void get_peri(int l,int b){
 System.out.println("perimeter of rectangle"+(2*(l+b)));
 }
}

class shape{
public static void main(String args[]){
System.out.println("enter shape");
String s1="squre";
String s2="rectangle";
String s3="circle";
String s;
int l,b;
double r;
Scanner sc=new Scanner(System.in);
s= sc.nextLine();
area O=new area();
if(s.compareTo(s1)==0)
{
System.out.println("enter parameter side");
l=sc.nextInt();
O.get_area(l);
O.get_peri(l);


}
else if(s.compareTo(s2)==0)
{
System.out.println("enter parameter l,b");
l= sc.nextInt();
b= sc.nextInt();
O.get_area(l,b);
O.get_peri(l,b);


}
else if(s.compareTo(s3)==0)
{
System.out.println("enter parameter radius");
r= sc.nextDouble();
O.get_area(r);
O.get_peri(r);

}
else{
System.out.println("no such shape exist");
}

}

}
