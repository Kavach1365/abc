import java.util.*;
import java.io.*;

public class polind{
public static void main(String args[]){
Scanner q=new Scanner(System.in);
int n=q.nextInt();
int r,s=0,N=n;
while(n!=0)
{
r=n%10;
n=n/10;
s=s*10+r;
}
System.out.println("reverse of num "+N+" is "+s);
if(N==s) System.out.println(N+" is palindrome");
else System.out.println(N+" is NOT palindrome");


}

}
