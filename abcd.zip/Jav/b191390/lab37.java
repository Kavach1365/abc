import java.util.*;


class lab37
{
	public static void main(String a[])
	{
		System.out.println("Enter string: ");
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		int c=s.length();
		String ss="";
		for(int i=c-1;i>=0;i--)
		{
		//s[i]=s[c-i];
		ss=ss+s.charAt(i);
		}
		System.out.println("Reversed string="+ss);
	}
}
