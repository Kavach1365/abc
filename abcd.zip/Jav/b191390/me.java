package dept;

 interface demo{
 void display_sub();
 
 }
 
 public class me implements demo{
 public void display_sub(){
 System.out.println("mechines,java,calculus");
 }}
