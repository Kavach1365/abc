import java.util.*;

abstract class shape_2d
{
	abstract double  getArea(double a);
}

abstract class shape_3d
{
	abstract double  getArea(double a);
	abstract double getVolume(double a);
}


class square extends shape_2d
{
	double getArea(double a)
	{return a*a;}	
}

class cube extends shape_3d
{
	double getArea(double a)
	{return 6*a*a;}
	double getVolume(double a)
	{return a*a*a;}	
}
class circle extends shape_2d
{
	double getArea(double a)
	{return 3.14f*a*a;}
}
class sphere extends shape_3d
{
	double getArea(double a)
	{return 4*3.14f*a*a;}
	double getVolume(double a)
	{return (4f/3f)*3.14f*a*a*a;}	
}

class lab51
{
	public static void main(String args[])
	{
	
	circle c1=new circle();
	sphere ss=new sphere();
	square s1=new square();
	cube cc=new cube();
	double x=c1.getArea(5f);
	System.out.println(x);
	System.out.println(s1.getArea(5f));
	System.out.println(ss.getVolume(5f));
	System.out.println(cc.getVolume(5f));
	}
		
}
