import shapes.*;

class week6_3{
    public static void main(String args[]){
    circle c=new circle();
    c.area(3);
    c.peri(3);
    
    square s=new square();
    s.area(3);
    s.peri(3);
    
    triangle t=new triangle();
    t.area(2,1);
    t.peri(1,3,6);
    }
   }
   

      
 
