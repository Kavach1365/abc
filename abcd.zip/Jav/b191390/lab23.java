import java.util.*;

class TV{
int channel,volume;
boolean on;

TV(){
channel=1;
volume=5;
on=false;
}

void turnOn(){on=true;}
void turnOff(){on=false;}
void setChannel(int cnum){if(on)channel=cnum;
else msg();
}
void setVolume(int vol){if(on) volume=vol;
else msg();
}
void channelUp(){if(on)channel++;
else msg();
}
void channelDown(){if(on)channel--;
else msg();
}
void volumeUp(){if(on)volume++;
else msg();
}
void volumeDown(){if(on)volume--;
else msg();
}

void status(){
System.out.printf("TV current status: \nchannelnum=%d\nvolume=%d\n",channel,volume);
System.out.println("on="+on);
}

void msg(){System.out.println("Tv is in off condition you can't do any activity, to do anything please TURN ON TV");}
}

class lab23{
public static void main(String args[]){
TV tv1;
tv1=new TV();
int e=1;
while(e)
{
int st=0;
System.out.println("would u like to on your TV enter 1 if not enter 0:");
scanf("%d",&st);
if(st) turnOn();
else {System.out.println("do u wanna exit(enter 0): ");
scanf("%d",&e);

System.out.println("enter sc-set cahnnel,sv-set volume,cu-channelup,cd-channeldown,vu,vd: ");
String 
}


}
}
