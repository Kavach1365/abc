import java.util.*;
import calculator.operation;

class week6_12{
 public static void main(String args[])
{
System.out.println("enter two numbers and operator");
double a=8,b=10;
 operation o=new operation();
//Scanner sc=new Scanner(System.in);
//a=new sc.nextInt();
//b=new sc.nextInt();
char ch= '+';

switch(ch){
            case'+':System.out.println(o.add(a,b));
            break;
            case'-':System.out.println(o.sub(a,b));
            break;
            case'*':System.out.println(o.mul(a,b));
            break;
            case'/':System.out.println(o.div(a,b));  
            break;

            case'%':System.out.println(o.mod(a,b));
            break;}
}

}
