package calculator;
 
  interface calsi{
  abstract double add(double a,double b);
  abstract double sub(double a,double b);
  abstract double div(double a,double b);
  abstract double mul(double a,double b);
  abstract double mod(double a,double b);
  }
