import java.util.*;

class person{
String name,address;
person(String name,String address){
this.name=name;
this.address=address;

}

void getname(){
System.out.println(name);}
void getadress(){
System.out.println(address);}

}

class student extends person{
int grades,numcourses=0;
String course;
Hashmap<String,Integer> cg= new Hashmap();

 student(String name,String address){
 super(name,address);
 
 }
 
 void addcg(String course,int grade){
 if(numcourses<30){
 cg.put(course,grade);
 numcourse++:
 
 }
 else{
 System.out.println("limit exit");}
 
 }
 
  void printgrade(){
  System.out.println(cg);
  
  }
  double avg_grade(){
  double avg=0;
  for(int i=0;i<cg.size();i++){
  avg+=cg[i];
  }
  avg=(avg/cg.size());
  return avg;
  }
  
  
  
  

}


class teacher extens preson
{
int num=1;
Vector<String> v=new Vector();
tercher(String name,String address){
super(name,address);
}

boolean addcourse(String course){
if(num<5){
if(v.contains(course))
return false;
else{
num++;
v.add(course);
return true;
}
}
else return true;


}

boolean removecourse(String course){

if(num>=0)
{
if(v.contains(course))
{
v.remove(course);
num--;
return true;
}
else return false;


}
else 
return false;

}

}

class 4.2{
public static void main(String args[]){
person p= new person("megha","rr");
student s= new student("jhanu","kmr");
teacher t= new teacher("xyz","unknown");



}


}
