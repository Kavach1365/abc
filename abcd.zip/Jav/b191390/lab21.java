import java.util.*;

class Circle{
double r;
Circle(double r)
{
this.r=r;
}

double getArea(){ 
return (22f/7f)*r*r;
}
double getPerimeter(){
return 2*(22f/7f)*r;
}

}

class lab21{
public static void main(String args[]){
Circle c1=new Circle(5f);
Circle c2=new Circle(10f);
Circle c3=new Circle(15f);

System.out.println("area of circle c1=="+c1.getArea());
System.out.printf("perimeter of circle c1==%.1f\n",c1.getPerimeter());
System.out.printf("area of circle c2==%.2f\n",c2.getArea());
System.out.printf("area of circle c3==%.2f\n",c3.getArea());

}
}
