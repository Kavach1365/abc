import java.util.*;

public class lab71
{
	public static void main(String arg[])
	{
		try{
			Scanner sc=new Scanner(System.in);
			int x=sc.nextInt();
		}
		catch(Exception InputMismatchException)
		{
			System.out.println("you entered a wrong input...");
		}
	}
}
