import java.util.*;


public class patterns
{
	private static int min(int a,int b)
	{if(a<b) return a;
	else return b;}
	public static void main(String args[])
	{
		int n=5,i,j;
		System.out.println("");
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
			System.out.print("*");
			}
			System.out.println();
		}
		
		System.out.println("PATTERN1");
		for(i=0;i<n;i++)
		{
			for(j=0;j<=i;j++)
			{
			System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();	
		System.out.println("1.2>>");
		for(i=0;i<n;i++)
		{
			for(j=1;j<=i;j++)
			{
			System.out.print(j);
			}
			System.out.println();
		}
		System.out.println();
		System.out.println("1.3>>");
		for(i=0;i<n;i++)
		{
			for(j=0;j<n-i;j++)
			{
			System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
		System.out.println("1.4>>printing binary by flipping...");
		
		for(i=1;i<=n;i++)
		{	int x=1;
			if(i%2==0) x=0;
			for(j=1;j<=i;j++)
			{
				System.out.print(x);
				x=1-x;
			}
			System.out.println();
		}
		
		System.out.println();
		System.out.println("PATTERN2.1");
		
		for(i=0;i<n;i++)
		{
			for(j=0;j<n-i-1;j++)
			System.out.print(" ");
			
			for(j=0;j<2*i+1;j++)
			System.out.print("*");
			
			for(j=0;j<n-i-1;j++)
			System.out.print(" ");
			
			System.out.println();
		}
		System.out.println("2.2>>>");
		
		for(i=0;i<2*n-1;i++)
		{
			for(j=0;j<i;j++)
			System.out.print(" ");
			
			for(j=0;j<2*n-1-2*i;j++)
			System.out.print("*");
			
			for(j=0;j<i;j++)
			System.out.print(" ");
			
			System.out.println();
		}
		
		
		System.out.println();
		System.out.println("PATTERN3==combining 1.1,1.3");
		
		for(i=1;i<2*n;i++)
		{
			int var=i;
			if(i>n) var=2*n-i;
			for(j=1;j<=var;j++)
			System.out.print("*");
			
			System.out.println();
		}
		
		System.out.println("PATTERN3.2  >combining 2.1,2.2");
		
		for(i=1;i<=2*n-1;i++)
		{
			int spaces,stars;
			if(i<=n){spaces=n-i; stars=2*i-1;}
			else {spaces=i-n; stars=(4*n)-(2*i)-1;}
			
			for(j=0;j<spaces;j++)
			System.out.print(" ");
			
			for(j=0;j<stars;j++)
			System.out.print("*");
			
			for(j=0;j<spaces;j++)
			System.out.print(" ");
			
			System.out.println();
			
			
			
		}
		
		
		for(i=1;i<=n;i++)
		{	int val;
			for(j=1;j<=i;j++)
			System.out.print(j);
			
			for(j=1;j<=2*n-2*i;j++)
			System.out.print(" ");
			
			int k=i;
			for(j=1;j<=i;j++)
				System.out.print(k--);
			
			System.out.println();
			
		}
		System.out.println();
		System.out.println();
		for(i=1;i<=2*n-1;i++)
		{
			if(i<=n)
			{
				for(j=1;j<=i;j++) System.out.print("*");
				for(j=1;j<=2*(n-i);j++) System.out.print(" ");
				for(j=1;j<=i;j++) System.out.print("*");
			}
			else
			{
				for(j=1;j<=2*n-i;j++) System.out.print("*");
				for(j=1;j<=2*(i-n);j++) System.out.print(" ");
				for(j=1;j<=2*n-i;j++) System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
		System.out.println("PATTERN-4");
		System.out.println();
		n=4;
		for(i=0;i<2*n-1;i++)
		{
			for(j=0;j<2*n-1;j++)
			{
				int x=min(min(i,j),min(2*n-2-i,2*n-j-2));
				System.out.print(n-x);
			}	
			System.out.println();			
		}
		
		
			
			
	}

}
