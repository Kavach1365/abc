package Mypackage;

public class X{
int n;
private int p;
protected int q;
public int r;
public X(){//constructor must be public as it was called
System.out.println("X constructor:");
System.out.println("n="+n);
//System.out.println("p="+p);
//System.out.println("q="+q);
System.out.println("r="+r);
}
}
