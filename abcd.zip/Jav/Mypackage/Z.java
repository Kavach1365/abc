package Mypackage1;

public class Z{
Z(){
Mypackage1.X x=new Mypackage1.X();
System.out.println("Z constructor:");
System.out.println("n="+x.n);
System.out.println("p="+x.p);
System.out.println("q="+x.q);
System.out.println("r="+x.r);
}

}
