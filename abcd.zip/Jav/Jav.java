
import Mypackage.X;
public class Jav{
public static void main(String args[]){
X x1=new X();

}
}
