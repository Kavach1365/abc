import java.util.*;

class product
{
	private int p_id,p_qty,p_price;
	private String p_name;
	
	product(int id,String name,int pr,int qt)
	{
		p_id=id; p_name=name; p_price=pr; p_qty=qt;
	}
	
	int getPid()
	{
		return p_id;
	}
	int getPqty()
	{
		return p_qty;
	}
	int getPprice()
	{
		return p_price;
	}
	String getPname()
	{
		return p_name;
	}


}



class lab3_11
{
	public static void main(String ar[])
	{
		Scanner sc=new Scanner(System.in);
		product p[]=new product[5];
		System.out.println("Enter product id,name,price,qty");
		int id,price,qty;
		String name;
		for(int i=0;i<5;i++)
		{
			id=sc.nextInt();
			name=sc.next();
			price=sc.nextInt();
			qty=sc.nextInt();
			
			p[i]=new product(id,name,price,qty);	
		}
		System.out.println("Enter the product-id and qty u wanna buy from the above list of products available in Store: ");
		
		int e=1,sum=0;
		do
		{
			int x=sc.nextInt();
			int q=sc.nextInt();
			int unit_price=0,f=0;
			for(int i=0;i<5;i++)
			{
				if(p[i].getPid()==x) 
				{
					unit_price=p[i].getPprice();
					if(q<=p[i].getPqty()) f=1;
				}
			}
			if(f==0) 
			{
				System.out.printf("\nTHE REQUIRED QUANTITY OF THIS PRODUCT NOT AVAILABLE IN STORE!!!\n");	
				System.out.println();
			}	
			else
			{sum=sum+(unit_price*q);}
			
			System.out.print("do u wanna buy one more product(enter 1-to buy,0-to enough): ");
			e=sc.nextInt();
			
		}while(e!=0);
		System.out.println("TOTAL RETAIL PRICE="+sum);
	
	}
}
