import java.util.*;

class thread4 extends Thread
{
	public void run()
	{
		System.out.println(Thread.currentThread().getId());
	}
}


class threadid1
{
	public static void main(String args[])
	{
		for(int i=0;i<5;i++)
		{
			thread4 t=new thread4();
			t.start();
		}
	
	}
}
