class First
{
public static void main(string args[])
{
system.out.println("hello world..");
}
}
