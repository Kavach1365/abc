import java.util.*;

class lab3_13
{
	public static void main(String rgs[])
	{
		int count=0;
		Random r=new Random();
		for(int i=0;i<10;i++)
		{
			try{
			int x=r.nextInt(5)+1;
			int y=r.nextInt(5)+1;
			if(x==y) count++;
			System.out.println("x="+x+"  y="+y);
			}
			catch(Exception e){
				System.out.printn(e);	
			}
			
		}
		System.out.println("NO.OF SUCCESSFUL ATTEMPTS="+count);
		
	}
}z
