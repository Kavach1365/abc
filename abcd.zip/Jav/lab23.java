import java.util.*;

class TV{
	int channel,vol;
	boolean on;
	TV(){
	this.channel=1;
	this.vol=10;
	this.on=false;
	}
	void turnOn(){on=true; System.out.println("this TV is ON now");}
	void turnOff(){on=false; System.out.println("this TV is OFF now");}
	void setChannel(int nc){this.channel=nc;}
	void setVolume(int v){this.vol=v;}
	void channelUp(){this.channel=this.channel+1;}
	void channelDown(){this.channel=this.channel-1;}	
	void volumeUp(){this.vol=this.vol+1;}
	void volumeDown(){this.vol=this.vol-1;}
}

class lab23{
	public static void main(String args[]){
		int e=1,i=0,n=2;
		Scanner sc=new Scanner(System.in);
		TV tv[]=new TV[n];
		while(i<n){
			tv[i]=new TV();//calling default constructor for all obj
			i++;
			}
			
		do{     
			System.out.printf("Enter TVnum(0-%d): ",n-1);
			int j=sc.nextInt();
			System.out.printf("Enter (1-turnON, 0-turnOff: ) ");			
			int ch=sc.nextInt();
			if(ch==1)
			{
				System.out.println("Enter (1-to setChannel)(2-setVolume)(3-channelUp)(4-channelDown)(5-volUp)(6-volDown):");
				int choice=sc.nextInt();
				switch(choice){
				case 1: 
					System.out.println("Enter channel NUM:");
					int cn=sc.nextInt();
					tv[j].setChannel(cn);
					break;
				case 2:
					System.out.println("Enter volume:");
					int vv=sc.nextInt();
					tv[j].setVolume(vv);
					break;
				case 3:
					tv[j].channelUp();
					break;
				case 4:
					tv[j].channelDown();
					break;
				case 5:
					tv[j].volumeUp();
					break;
				case 6:
					tv[j].volumeDown();
					break;
				default:
					tv[j].turnOff();
														
			}
			}
			System.out.println("do u wanna exit(enter 0-exit, 1-continue): ");
			e=sc.nextInt();
			
			
		}while(e!=0);
	
	}



}

