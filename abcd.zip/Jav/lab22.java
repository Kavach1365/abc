import java.util.*;

class Lamp{
	boolean ison;
	String lampType;
	Lamp(String lt){
		this.lampType=lt;
		this.ison=false;  //by default the lamp of any type is off
	}
	Lamp(String lt,boolean ison){
		this.lampType=lt;
		this.ison=ison;
	}
	void turnOn(){
		this.ison=true;
		System.out.println(lampType+" is on now");
	}
	void turnOff(){
		this.ison=false;
		System.out.println(lampType+" is off now");
	}
	void getStatus(){
		if(ison)
		System.out.println(lampType+" is in ON condition");
		else
		System.out.println(lampType+" is in OFF condition");
	}
	void changeStatus(){
		ison=true?false:true;	
		if(ison) System.out.println(lampType+" is on now");	
		else System.out.println(lampType+" is off now");
	}
}

class lab22{
	public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
		System.out.println("Enter max no.of obj u wanna create:");
		int n=sc.nextInt();
		Lamp l[]=new Lamp[n];
		int e=1,i=0;
		while(i<n){
			System.out.printf("enter lampType for lamp%d: ",i);
			String ss=sc.next();
			System.out.printf("enter intial state(0-off,1-on) for lamp%d: ",i);	
			int s=sc.nextInt();
			boolean b=(s==1)?true:false;
			l[i]=new Lamp(ss,b);	
			i++;
		}
		do{
			System.out.printf("Enter lampnum(0-%d): ",n-1);
			int j=sc.nextInt();
			System.out.printf("Enter (1-to get status,2-to alter(on>>off & off>>on)status,3-to on,4-off: ) ");			
			int choice=sc.nextInt();
			switch(choice){
				case 1: 
					l[j].getStatus();
					break;
				case 2:
					l[j].changeStatus();
					break;
				case 3:
					l[j].turnOn();
					break;
				case 4:
					l[j].turnOff();
					break;
					
				default:
														
			}
			System.out.println("\n\nDo u wanna exit(enter 0 to exit 1 to continue:): ");
			e=sc.nextInt();
		}while(e!=0);
		
	}
}


