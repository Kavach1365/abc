import java.util.*;


class Emp
{
	private int id,age,salary;
	private String name,designation,address;
	
	Emp(int id,int age,int salary,String name,String desg,String addr)
	{
	this.id=id; this.salary=salary; this.age=age; this.name=name;
	designation=desg; address=addr;
	}
	
	int getId()
	{
		return id;
	}

	String getName(int id)
	{
		return name;
	}
	String getDesignation(int id)
	{
		return name;
	}
	String getAddress(int id)
	{
		return name;
	}
	int getSalary(int id)
	{
		return salary;
	}
	int getAge(int id)
	{
		return age;
	}

}


class lab3_10
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no.of employees: ");
		int n=sc.nextInt();
		Emp e[]=new Emp[n];
		int id,age,sal;
		String name,desg,adr;
		System.out.println("Enter id,name,designation,salary,age,address:");
		for(int i=0;i<n;i++)
		{
		id=sc.nextInt();
		name=sc.next();
		desg=sc.next();
		sal=sc.nextInt();
		age=sc.nextInt();
		adr=sc.next();
		e[i]=new Emp(id,age,sal,name,desg,adr);
		}
		
		System.out.print("enter empid to get details: ");
		int x=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			int idd=e[i].getId();
			if(idd==x)
			{
				System.out.printf("name=%s  age=%d  adres=%s  designation=%s  salary=%d\n",e[i].getName(idd),e[i].getAge(idd),e[i].getAddress(idd),e[i].getDesignation(idd),e[i].getSalary(idd));
			}
		}
	}
}
