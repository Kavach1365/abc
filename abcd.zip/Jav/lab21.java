import java.util.*;

class Circle{
	double r;
	Circle(){
		this.r=0f;
		}
	Circle(double r){
			this.r=r;
	}
	double getArea(){
		return (22f/7f)*r*r;
	}
	double getPerimeter(){
		return 2*(22f/7f)*r;
	}
}

class lab21{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter max no.of obj u wanna create:");
		int n=sc.nextInt();
		Circle c[]=new Circle[n];
		int e=1,i=0;
		while(i<n){
			System.out.printf("enter radious for c%d: ",i);
			double r=sc.nextDouble();
			c[i]=new Circle(r);
			i++;
		}
		do{
			System.out.printf("Enter circle num(bw 1 - %d) for which u want area(1 to calc area),perimeter(2 to calc): ",n);
			int cir_no=sc.nextInt();
			int choice=sc.nextInt();
			switch(choice){
				case 1: 
					System.out.printf("Area of circle%d is %.2f",cir_no,c[cir_no].getArea());
					break;
				case 2:c[cir_no].getPerimeter();
					System.out.printf("Perimeter of circle%d is %.2f",cir_no,c[cir_no].getPerimeter());					
					break;
				default:
					System.out.printf("Area of circle%d is %.2f",cir_no,c[cir_no].getArea());
					System.out.printf("\nPerimeter of circle%d is %.2f",cir_no,c[cir_no].getPerimeter());									
			}
			System.out.println("\n\nDo u wanna exit(enter 0 to exit 1 to continue:): ");
			e=sc.nextInt();
		}while(e!=0);

	}
}
