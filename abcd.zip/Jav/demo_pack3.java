import java.util.*;
import pack3.*;
class demo_pack3
{
	public static void main(String args[])
	{
		Date_implem o=new Date_implem();
		o.showdate();
	}
}
