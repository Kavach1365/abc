import java.util.*;
class threadx implements Runnable
{
	public void run()
	{
		for(int i=0;i<3;i++)
		System.out.println("i="+i);
		
		System.out.println("exiting threadX...");
	}	
}

class thready implements Runnable
{
	public void run()
	{
		for(int j=0;j<10;j++)
		{
		System.out.println("j="+j);
		}
		System.out.println("exiting threadY...");
	}
}

class threads_2
{
	public static void main(String arg[])
	{	//we should pass the object created usind runnabl interface to the class Thread to create threate obj
		threadx a=new threadx();
		Thread t1=new Thread(a);
		
		Thread t2=new Thread(new thready());//
		
		t1.start();
		t2.start();
		System.out.println("Exiting main...");
	}
}
