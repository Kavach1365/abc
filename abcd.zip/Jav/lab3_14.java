import java.util.*;

class book
{
	private String book_name,book_author;
	int book_count;
	
	book(String name,String aut,int c)
	{
		book_name=name;
		book_author=aut;
		book_count=c;
	}
	
	String getName()
	{
		return book_name;
	}
	int getCount()
	{
		return book_count;
	}
	
	int Buybook(String name)
	{
		if(book_count>=1)
		{
			book_count--;
			return book_count;
		}
		else
		{
			System.out.println("THIS BOOK IS NOT AVAILABLE!!!...");
			return 0;
		}
	}
	
	
}

class customer
{
	int customer_id,count=0;
	private String customer_name,customer_address;
	String book_list[]=new String[10];
	HashMap <String,Integer> h=new HashMap<>();
	
	customer(int id,String name,String adr)
	{
	customer_id=id;
	customer_name=name;
	customer_address=adr;
	}
	
	int getCusId()
	{
		return customer_id;
	}
	
	//void addBook(String name)
	//{
		
	//	book_list[count]=name;
	//	count++;
	//}
}

class lab3_14
{
	public static void main(String arg[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter no,of books:");
		int bc=sc.nextInt();
		book b[]=new book[bc];
		System.out.println("Enter book name,author,count:");
		for(int i=0;i<bc;i++)
		{
			String name=sc.next();
			String aut=sc.next();
			int c=sc.nextInt();
			b[i]=new book(name,aut,c);
		}
		
		
		System.out.print("Enter no.of customers: ");
		int cc=sc.nextInt();
		customer c[]=new customer[cc];
		System.out.println("Enter customer id,name,address: ");
		for(int i=0;i<cc;i++)
		{
			int id=sc.nextInt();
			String cname=sc.next();
			String adr=sc.next();
			c[i]=new customer(id,cname,adr);
			
		}
		
		System.out.println("Enter your CUST_ID, and the BOOK_NAME u want to buy,no.of books: ");
		while(true){
		int idd=sc.nextInt();
		String Name=sc.next();
		int f=sc.nextInt();
		Integer d=f;
		
		for(int i=0;i<bc;i++)
		{	//System.out.printf("in i%d loop %s",i,b[i].getName());
			if((b[i].getName()).equals(Name))
			{	//System.out.printf("in ifff ");
				//System.out.println("bookName="+Name+"   bookCount="+b[i].Buybook(Name));
				b[i].book_count-=d;
				
				for(int j=0;j<cc;j++)
				{
					if(c[j].getCusId()==idd)
					{	
					//c[j].addBook(Name);
					c[j].h.put(Name,d);
					c[j].count=c[j].count+d;
					break;
					}
				}
		}
			}
			System.out.println("Enter 0-exit");
			if((sc.nextInt())==0)break;
		}
		
		
		for(int i=0;i<cc;i++)
		{
			//System.out.println(c[i].count);
			System.out.println();
			System.out.println(i+"cusId= "+c[i].customer_id+"tot.no.of.books= "+c[i].count);
			
			
			//for(int j=0;j<c[i].h.length;j++)
			//{
			//	System.out.println();	
			//}
			
			for(String j:c[i].h.keySet())
			{
			System.out.println(j+"  :"+c[i].h.get(j));
			}
			
			/*
			for(String j:h.keySet())
			{
			System.out.println(j+"  :"+h.get(j));
			}*/
		}
		
		//System
		
		
		
	}
}
