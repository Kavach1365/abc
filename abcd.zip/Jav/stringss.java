import java.util.*;

class stringss
{

	public static void main(String arg[])
	{
		String s1="Hiii";
		String s2=" Alekhya";
		
		System.out.println(s1.compareTo(s2));
		System.out.println((int)'H'-(int)' ');
		System.out.println((int)'A'+" a= "+(int)'a'+" 0=  "+(int)'0');
	}
}
