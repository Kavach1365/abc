import java.util.*;

class dem
{
	public static void main(String []a)
	{
		
		try{
			int b[]={5,2,4};
			b[92]=67;
			
		}
		catch(Exception ai)
		{
			System.out.println(ai);
		}
	}
}
