package m65;

public class m65pack_class
{
	int rp,ip;
	
	m65pack_class()
	{
		this.rp=0; this.ip=0;
	}
	
	m65_pack_class(int rp,int ip)
	{this.rp=rp; this.ip=ip;}
	
	add()
	{}
}

