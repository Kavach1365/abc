// a. Include the package complex
import complex.Complex;

// b. Create a class Arith and declare rp, ip as integer.
class Arith {
    int rp, ip;

    // c. Define the function Arith(), set rp and ip to 0
    Arith() {
        rp = 0;
        ip = 0;
    }

    // d. Another function Arith(int rp, int ip) set this.rp=rp and this.ip=ip
    Arith(int rp, int ip) {
        this.rp = rp;
        this.ip = ip;
    }

    // e. create a method add() pass arguments with arith a1 and arith a2
    void add(Arith a1, Arith a2) {
        // f. add a1.rp and a2.rp store in rp. g. Similarly add a1.ip and a2.ip and store in ip.
        rp = a1.rp + a2.rp;
        ip = a1.ip + a2.ip;
    }

    // h. Create a function sub(arith a1,arith a2)
    void sub(Arith a1, Arith a2) {
        // i. Subtract a1.rp and a2.rp store it in rp. j. Subtract a1.ip and a2.ip store it in ip.
        rp = a1.rp - a2.rp;
        ip = a1.ip - a2.ip;
    }
}

// Main class
public class ComplexCalculator {
    public static void main(String[] args) {
        // k. Import the package and calculate the addition and subtraction of two complex numbers.
        
        // Sample I/p and O/p:
        // Enter real part and imaginary part of 1st complex no: 10 5
        // Enter real part and imaginary part of 2nd complex no: 3 6

        System.out.println("Enter real part and imaginary part of 1st complex no:");
        int rp1 = 10; // replace with user input
        int ip1 = 5; // replace with user input

        System.out.println("Enter real part and imaginary part of 2nd complex no:");
        int rp2 = 3; // replace with user input
        int ip2 = 6; // replace with user input

        // Create complex numbers
        Complex a1 = new Complex(rp1, ip1);
        Complex a2 = new Complex(rp2, ip2);

        // Display complex numbers
        System.out.println("a1=" + a1);
        System.out.println("a2=" + a2);

        // Calculate and display addition
        Arith sum = new Arith();
        sum.add(a1, a2);
        System.out.println("Added value: " + sum.rp + "+" + sum.ip + "i");

        // Calculate and display subtraction
        Arith diff = new Arith();
        diff.sub(a1, a2);
        System.out.println("Subtracted value: " + diff.rp + "+" + diff.ip + "i");
    }
}

