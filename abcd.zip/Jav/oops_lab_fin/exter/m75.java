import java.util.*;


class Exception1 extends Exception
{
	Exception1(String m){super(m);}
}
class book
{
	boolean b1[]=new boolean[70];
	boolean b2[]=new boolean[70];
	boolean s1[]=new boolean[70];
	boolean s2[]=new boolean[70];
	
	void bookTicket(int n,String type)throws Exception1
	{
	for(int i=0;i<70;i++)
	{
	b1[i]=false;
	b2[i]=false;
	s1[i]=false;
	s2[i]=false;
	
	}
	
	String booked[]=new String[n];
	
	if(n>6) throw new Exception1("you may be an agent..");
	else
	{
		int c=0;
		while(c<n){
		
		if(type.equals("A/C"))
		{
			Random r=new Random();
			int x=r.nextInt(140);
			
			if(x<70 && b1[x]!=true) {b1[x]=true; booked[c]="b1"+Integer.toString(x); c++; }
			else if(b2[x-70]!=true) {b2[x-70]=true; booked[c]="b2"+Integer.toString(x-70); c++;}
		}
		if(type.equals("sleeper"))
		{
			Random r=new Random();
			int x=r.nextInt(140);
			
			if(x<70 && s1[x]!=true) {s1[x]=true; booked[c]="s1"+Integer.toString(x); c++;}
			else if(s2[x-70]!=true) {s2[x-70]=true; 
			booked[c]="s1"+Integer.toString(x-70);
			c++;}
		}
		}
		
		
		System.out.println("Booked berths: ");
		for(int i=0;i<n;i++)
		{
		System.out.printf("%s ",booked[i]);
		}
		
		
		
	}
	
	}
	
}

public class m75
{
	public static void main(String arg[])
	{
	 book b=new book();
	 
	 try{
	 b.bookTicket(5,"A/C");
	 }
	 catch(Exception e){System.out.println(e);}
	}
}
