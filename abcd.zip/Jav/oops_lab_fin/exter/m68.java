import java.util.*;
import TotalFare.passengers;
import TotalFare.m68intf_reserve_cost;
import TotalFare.m68Reserve_Class;
public class m68
{
	public static void main(String arg[])
	{
		System.out.println("Enter no.of passengers: ");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		TotalFare.passengers p[]= new passengers[n];
		
		System.out.println("Enter age,student(true/false): ");
		for(int i=0;i<n;i++)
		{
			p[i]=new TotalFare.passengers(sc.nextInt(),sc.nextBoolean());
		}
		TotalFare.m68Reserve_Class r=new TotalFare.m68Reserve_Class(100.0);
		double x=r.totalFare_method(p);
		System.out.println(x);
	
	}
}
