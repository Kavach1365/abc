package TotalFare;

public interface m68intf_reserve_cost
{
	double totalFare_method(passengers p[]);
}


