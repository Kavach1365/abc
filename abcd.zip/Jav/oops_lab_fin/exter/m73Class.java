package audit;

 class FraudException extends Exception
{
	FraudException(String msg)
	{super(msg);}
}

public class m73Class
{
	double tax,e1,e2,i;
	public m73Class(double a,double b,double c,double i)
	{tax=a; e1=b; e2=c; this.i=i;}
	
	public void taxChecker() throws FraudException
	{
		double t_toBePaid=0.1*(i-(e1+e2));
		if(t_toBePaid>tax)
		{throw new FraudException("fraud..");}
	}
	

}
