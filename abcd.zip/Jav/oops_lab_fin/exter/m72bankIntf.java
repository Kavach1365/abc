package Bank;

public interface m72bankIntf
{
	void credentialCheck(String userName,String password) throws InvalidInfoException;
	void credit(double amt);
	void debit(double amt) throws InsufficientBalanceException;
	//void displayBalance();
	//void exit();
}
