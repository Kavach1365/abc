import java.util.*;
import calculator.m61_pack_class;

public class m61
{
	public static void main(String args[])
	{
		double x=6.5,y=2.0;
		m61_pack_class c=new m61_pack_class();
		System.out.println(c.add(x,y));
	}

}

