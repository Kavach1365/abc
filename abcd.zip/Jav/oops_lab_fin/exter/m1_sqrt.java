import java.util.*;

//import java.lang.Math.*;

public class m1_sqrt
{
	public static void main(String arg[]){
	//double a=3,b=4,c=0;
	//Math.sqrt(b);
	System.out.println(Math.sqrt(17));
	System.out.println(Math.pow(4.1,2.3));
	}
}
