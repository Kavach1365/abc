package shapes;

public class m63_square
{
	double a;
	public double getArea(double a)
	{return a*a;}
}
