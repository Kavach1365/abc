package calculator;

public class m61_pack_class implements m61pack_intf
{
	public double add(double a,double b)
	{return a+b;}
	public double subtract(double a,double b)
	{return a-b;}
	
	public double multiply(double a,double b){
	return a*b;
	}
	public double divide(double a,double b)
	{return a/b;}
}
