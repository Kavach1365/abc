package M_seva;
import java.util.*;//for ARRAYLIST usage

interface disease
{
	
	void display(ArrayList<String> s);
}
