package Tv_remote;

interface m67pack_intf
{
	
}
