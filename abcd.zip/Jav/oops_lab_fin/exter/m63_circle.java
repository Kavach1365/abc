package shapes;

public class m63_circle
{
	public double getArea(double r)
	{return (22/7)*r*r;}
}
