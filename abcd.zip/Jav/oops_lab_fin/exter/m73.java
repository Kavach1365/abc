import java.util.*;
import audit.m73Class;

public class m73
{

public static void main(String arg[])
{
	m73Class c=new m73Class(10,4,1,200);
	
	try{
		c.taxChecker();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}
}
