package TotalFare;
import java.util.*;

public class m68Reserve_Class implements m68intf_reserve_cost
{
	
	public double tot=0,aCost;
	
	public m68Reserve_Class(double a)
	{
		this.aCost=a;
		//System.out.println("a="+aCost);
	}
	
		
	
	public double totalFare_method(passengers p[])
	{
	
		
		for(int i=0;i<p.length;i++)
		{
		//p[i].genCost=this.actualCost;
		p[i].actualCost=this.aCost;
		//System.out.println("a="+p[i].actualCost);
		}
		
		
		for(int i=0;i<p.length;i++)
		{
			if(p[i].age<=5) p[i].actualCost=0;
			if(p[i].age>5 && p[i].age<=25 && p[i].student){ p[i].actualCost=p[i].actualCost-(0.3)*p[i].actualCost;
						//System.out.println("....."+i);
			}
			if(p[i].age>55)  p[i].actualCost=p[i].actualCost-(0.5)*p[i].actualCost;
			System.out.println(p[i].actualCost);
			
			tot=tot+p[i].actualCost;
		}
		return tot;		
	}
}

