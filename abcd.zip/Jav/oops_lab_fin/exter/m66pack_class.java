package M_seva;
import java.util.*;
public class m66pack_class implements disease//here can write M_seva.disease
{
	String com[]={"stomach ache","vomiting","low eye sight"};
	String ap[]={"muscle ache","fever"};
	String a[]={"fever","fatigue"};
	String pc[]={"fever","fatigue"};
	String bc[]={"skin allergy","low bp"};
	public void display(ArrayList<String> s)
	{
	
	
	int f=1;
	for(int i=0;i<com.length;i++)
	{
		if(!(s.contains(com[i]))){ System.out.println("not disease"); f=0; break;}
	}
	if(f==1)
	{	f=1;
		for(int i=0;i<ap.length;i++)
		{
			if(!(s.contains(ap[i]))) {f=0; break;}
		}
		if(f==1) System.out.println("AP");
		
		f=1;
		for(int i=0;i<a.length;i++)
		{
			if(!(s.contains(a[i]))) {f=0; break;}
		}
		if(f==1) System.out.println("A");
		
		f=1;
		for(int i=0;i<pc.length;i++)
		{
			if(!(s.contains(pc[i]))) {f=0; break;}
		}
		if(f==1) System.out.println("PC");
		
		f=1;
		for(int i=0;i<bc.length;i++)
		{
			if(!(s.contains(bc[i]))) {f=0; break;}
		}
		if(f==1) System.out.println("BC");
	}
	
	
	
	
	
	
	
/*			int j=0;//String f[]={"stomach ache","vomiting","low eye sight","muscle ache","fever"};
			while(j<com.length)
			{
				int i=0,f=0;
				for( i=0;i<s.length;i++)
				{	
					if((com.get(i)).equalsIgnoreCase(s.get(i)))
					{
						j++;
						f=1;
					}
					System.out.println(i);
					if(j==com.length) break;
				}
				if(i==s.length && j!=com.length && f==0) break;
			
			}
			if(j==com.length) 
			{
				int x=0;
				while(x<ap.length)
				{	int i=0;
					for(i=0;i<s.length;i++)
					{
						if(ap[x].equalsIgnoreCase(s[i]))
						j++;
						
						if(x==ap.length) break;
					}
					if(i==s.length && x!=ap.length) break;
					
				}
				if(x==ap.length) System.out.println("AP");
				
			}*/
	}
}







