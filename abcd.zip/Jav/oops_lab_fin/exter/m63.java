import shapes.*;


public class m63
{
	public static void main(String args[])
	{
	shapes.m63_square m=new shapes.m63_square();
	System.out.println(m.getArea(2.5));
	}
}
