package Bank;
import java.util.*;

//class InvalidInfoException extends Exception
//{
	//InvalidInfoException(String msg)
	//{}//super(msg);}
//}

//class InsufficientBalanceException extends Exception
//{
//	InsufficientBalanceException(String msg){super(msg);}
//}



public class m72bankClass implements m72bankIntf
{

	public String uname,password;
	public double bal=0;
	public m72bankClass(String u,String p)
	{
	uname=u; this.password=password;	
	}
	
	public void credentialCheck(String userName,String password) throws InvalidInfoException
	{
		if((userName.equals(this.uname)) &&(password.equals(this.password)))	
		{
		int h=0;
		//throw new InvalidInfoException("..invalid..");
		}
		else{throw new InvalidInfoException("..invalid..");}
	}
	
	public void credit(double amt)
	{bal=bal+amt;
			System.out.println("...in credit");
	}
	
	public void debit(double amt) throws InsufficientBalanceException
	{
		if(amt>bal) throw new InsufficientBalanceException("..not enough..");	
		else bal=bal-amt;
	}
}
