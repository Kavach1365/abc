package TotalFare;

public class passengers
{
	int age;
	boolean student;
	double genCost,actualCost;
	passengers(int a,boolean stud)
	{age=a; student=stud;}
}
