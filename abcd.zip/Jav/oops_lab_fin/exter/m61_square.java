package shapes;

class m61_square
{
	
}
