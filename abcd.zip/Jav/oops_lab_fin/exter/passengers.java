package TotalFare;

public class passengers
{
	public int age;
	public boolean student;
	public double actualCost;
	public passengers(int a,boolean stud)
	{age=a; student=stud;}
}
