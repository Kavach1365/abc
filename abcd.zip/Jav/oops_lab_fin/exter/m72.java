import java.util.*;
import Bank.m72bankClass;

public class m72
{
	public static void main(String rg[])
	{
		m72bankClass c=new m72bankClass("ali","3423");
		
		try{
		c.credentialCheck("ali","3423");
		c.credit(100);
		c.debit(700);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println(c.bal);
		
	}
}
