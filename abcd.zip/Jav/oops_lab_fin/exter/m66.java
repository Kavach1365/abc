import M_seva.*;
import java.util.*;

public class m66
{
	public static void main(String arg[])
	{
		M_seva.m66pack_class c=new M_seva.m66pack_class();//only using m66pack_class(  class name)...error
		ArrayList<String> f=new ArrayList<String>();
		f.add("fever");
		f.add("stomach ache");
		f.add("vomiting");
		f.add("low eye sight");
		f.add("fatigue");
		f.add("muscle ache");
		
		c.display(f);	
	}

}
