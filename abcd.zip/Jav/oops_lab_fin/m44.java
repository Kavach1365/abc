import java.util.*;

class vehicle
{
	String company,model;
	int mileage,fuelCapacity;
	vehicle(String comp,String mod,int fuel,int mil)
	{
		company=comp; model=mod; fuelCapacity=fuel; mileage=mil;
	}
}

class two_wheeler extends vehicle
{
	String headlight,userReview;	
	two_wheeler(String comp,String mod,int milg,int fuel,String hl,String ur)
	{
		super(comp,mod,milg,fuel);
		this.headlight=hl;
		this.userReview=ur;
	}
}

class four_wheeler extends vehicle
{
	boolean ac,airBags;
	four_wheeler(String comp,String mod,int milg,int fuel,boolean ac,boolean airBags)
	{
	super(comp,mod,milg,fuel);
	this.ac=ac; this.airBags=airBags;
	}
}

public class m44
{

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		Vector <two_wheeler> t=new Vector<>();
		Vector <four_wheeler> f=new Vector<>();
		int tn=0,fn=0,c=1;
		while(c!=0)
		{
			System.out.printf("\n1:two-wheeler\n0-exit\n");
			c=sc.nextInt();
			if(c==1) 
			{
				System.out.println("Enter company,model,mileage,fuelCAPACITY,headlight,userReview: ");
				t.add(new two_wheeler(sc.next(),sc.next(),sc.nextInt(),sc.nextInt(),sc.next(),sc.next()));
				tn++;
			}
			else if(c==0)
			{
				if(tn<3) 
				{System.out.println("There must be min4 2-wheelers in shop!!");
				c=1;
				}
			}
		}
		
		c=1;
		while(c!=0)
		{
			System.out.printf("\n1:four-wheeler\n0-exit\n");
			c=sc.nextInt();
			if(c==1) 
			{
				System.out.println("Enter company,model,mileage,fuelCAPACITY,ac(true/false),airbags(true/false): ");
				f.add(new four_wheeler(sc.next(),sc.next(),sc.nextInt(),sc.nextInt(),sc.nextBoolean(),sc.nextBoolean()));
				fn++;
			}
			else if(c==0)
			{
				if(fn<3) 
				{System.out.println("There must be min4 4-wheelers in shop!!");
				c=1;
				}
			}
		}
		
		System.out.println();
		System.out.println("what you want to buy(Enter):");
		System.out.printf("\n1:twoWheeler\n2:FourWheeler\n");
		c=sc.nextInt();
		switch(c)
		{
			case 1:
			System.out.printf("\n\nAvailable MODELS:\n");
			for(int i=0;i<tn;i++)
			System.out.println(t.get(i).model);
			System.out.println();
			
			
			System.out.println("Enter how many models you want to compare: ");
			int n=sc.nextInt();
			//String u[]=new String[n];
			System.out.println("Enter models to compare: ");
			int max=-1;
			String best="";
			for(int i=0;i<n;i++)
			{
				String u=sc.next();
				for(int j=0;j<tn;j++)
				{
					//if((t[j].model).equals(u) && max<t[j].mileage)
					if((t.get(j).model).equals(u) && max<t.get(j).mileage)
					{
						max=t.get(j).mileage;
						best=best+u;
					}
					
				}
			}
			System.out.println("Best 2-wheeler among your selected model is: "+best);
			
		}
	}
}
