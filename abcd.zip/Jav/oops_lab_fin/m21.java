 import java.util.*;
 
 class Circle
 {
 	double r;
 	Circle(double r)
 	{this.r=r;}
 	
 	double getArea()
 	{return Math.PI*r*r;}
 	
 	double getPerimeter()
 	{return Math.PI*2*r;}
 }
 
 public class m21
 {
 	public static void main(String arg[])
 	{
 	Circle c1=new Circle(5f);
 	Circle c2=new Circle(10f);
 	Circle c3=new Circle(15f);
 	
 	System.out.println("Circle1 area= "+c1.getArea()+"  Perimeter="+c1.getPerimeter());
 	System.out.println("Circle1 area= "+c2.getArea()+"  Perimeter="+c2.getPerimeter());
 	System.out.println("Circle1 area= "+c3.getArea()+"  Perimeter="+c3.getPerimeter()); 	
 	}
 	
 	
 }
 
 
