import java.util.*;

class Account
{
	double act_bal;
	String bank_name,branch_name,act_name,act_adr;
	int act_num;
	Account(String bname,String brname,String aname,String aadr,int anum,double bal)
	{
	bank_name=bname; branch_name=brname; act_name=aname; act_num=anum;
	act_adr=aadr;
	if(bal>1000)
	act_bal=bal;
	else
	System.out.println("Intial balance should be>1000");
	}
	
	void credit(double amt)
	{
		act_bal+=amt;
		System.out.println("your account is Successfully credited with amount.."+amt);
	}
	
	void debit(double amt)
	{
	if(amt<=act_bal)
	{act_bal-=amt;
	System.out.println("your account is Successfully debited with amount.."+amt);}
	else
	System.out.println("INSUFFICIENT BALANCE..please make sure your act has sufficient balance...");
	}
	
	double getBalance()
	{return act_bal;}
	
	
	
}

public class m45{

public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	Account niz[]=new Account[3];
	Account bsr[]=new Account[3];
	niz[0]=new Account("sbi","nzb","alex","knr",79383,51550.0);
	niz[1]=new Account("bob","nzb","john","hyd",54413,14350.0);
	niz[2]=new Account("indianBank","nzb","nik","nzb",23413,31550.0);
	
	bsr[0]=new Account("sbi","bsr","alex","knr",23475,51550.0);
	bsr[1]=new Account("bob","bsr","john","hyd",97832,14350.0);
	bsr[2]=new Account("indianBank","bsr","nik","nzb",12533,31550.0);
	
	
	int c=1;
	while(c!=0)
	{
		System.out.println("please Enter username,password to start the transaction: ");
		System.out.printf("Username:");
		String u=sc.next();
		System.out.printf("Password:");
		int p=sc.nextInt();
		//System.out.println("..."+u+"..."+p);
		int f=0;
		for(int i=0;i<3;i++)
		{
			//System.out.println("..."+u+"..."+p);
			if(u.equals("nzb") && p==niz[i].act_num)
			{
				f=1;
				int x=1;
				while(x!=0)	
				{
				System.out.printf("\n1:credit\n2:debit\n3:check balance\n0:exit\n");
				x=sc.nextInt();
				switch(x)
				{
					case 1:
					System.out.print("Enter amount to be credited: ");
					niz[i].credit(sc.nextDouble());
					
					break;
					
					case 2:
					System.out.print("Enter amount to be debited: ");
					niz[i].debit(sc.nextDouble());
					break;
					
					case 3:
					System.out.println("Your Acoount current Balance is "+niz[i].getBalance());
					break;
					
					default:
					x=0;
					
							
				}
				}
				
			}
		}
		if(f==0)
		System.out.println("INVALID USERNAME OR PASSWORD...");
		
	System.out.printf("\npress 0:exit \n1:continue with other user:\n");	
	c=sc.nextInt();	
		
		
	}
			
}
}
