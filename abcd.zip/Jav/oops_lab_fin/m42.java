import java.util.*;

class person
{
	String name,addr;
	person(String n,String a)
	{
	this.name=n; 
	this.addr=a;
	}
}

class student extends person
{
	int n=0;
	//String courses[]=new String[30];
	//int grades[]=new grades[30];
	        List <Integer> grades = new ArrayList<>(30);
	        List <String> courses=new ArrayList<>(30);
	
	 
	student(String name,String a)
	{
		super(name,a);
	}
	
	
	void addCourseGrade(String c,int g)
	{
		n++;
		if(n<31){
		courses.add(c);
		grades.add(g);}
		else
		System.out.println("a studt can't take more than 30 courses");
		this.display();	
	}
	
	void display()
	{
		/*for(int i=0;i<n;i++)
		{
			System.out.println(courses[i]+" "+grades[i]);
		}*/
		System.out.println(courses);
		System.out.println(grades);
	}
	
	double avgGrade()
	{
		double avg=0;
		for(int i=0;i<n;i++)
		{
			avg=avg+grades.get(i);
		}
		return avg/n;
	}	
}


class teacher extends person
{
	int n=0;
	//String courses[]=new courses[n];
	List <String> courses=new ArrayList<>(5);
	teacher(String name,String a)
	{
		super(name,a);
	}
	
	boolean addCourse(String c)
	{
		n++;
		if(n<6)
		{
			if(courses.contains(c))
			return false;
			else
			{
				courses.add(c);
				return true;
			}
		}
		else
		{
		System.out.println("a teacher can teach only 5 courses");
		return false;
		}
	
	}
	
	boolean removeCourse(String c)
	{
		if(courses.contains(c))
		{courses.remove(c); return true;}
		else
		{System.out.println("the course does'nt exist..");
		return false;}			
	}
}

public class m42
{
	public static void main(String arg[])
	{
		Scanner sc=new Scanner(System.in);
		student s[]=new student[10];
		teacher t[]=new teacher[10];
		
		int c=1,sn=0,tn=0;
		System.out.println("Menu: ");
		while(c!=0)
		{
			System.out.printf("\n1:student\n2:teacher\n(0-exit):\n ");
			c=sc.nextInt();
			switch(c)
			{
				case 1:
				System.out.println("Enter stud name,addr: ");
				s[sn++]=new student(sc.next(),sc.next());
				int x=1;
				while(x!=0)
				{
					System.out.printf("\n1:addCourse\n0:exit:\n");
					x=sc.nextInt();
					if(x==1)
						{
						System.out.println("Enter course name,grade: ");
						s[sn-1].addCourseGrade(sc.next(),sc.nextInt());
						}
					
				}
				break;
				case 2:
				System.out.println("Enter teacher name,addr: ");
				t[tn++]=new teacher(sc.next(),sc.next());
				x=1;
				while(x!=0)
				{
					System.out.printf("\n1:addCourse\n0:exit:\n");
					x=sc.nextInt();
					if(x==1)
						{t[tn-1].addCourse(sc.next());
						}
					
				}
					
				
			}
		}
		
	}
}
