import java.util.*;

class Tv
{
	int ch,vol;
	boolean on;
	Tv(boolean on,int ch,int vol)
	{
		this.on=on;
		this.ch=ch;
		this.vol=vol;
	}
	
	void status()
	{
		System.out.println("channel num: "+this.ch);
		System.out.println("volume level: "+this.vol);
		System.out.println();

	}
	
	void turnOn()
	{this.on=true;}
	void turnOff()
	{this.on=false;}
	void setChannel(int c)
	{
	if(c>0 && c<41)
	this.ch=c;
	else
	System.out.println("Invakid channel num (channel num should be bw 1-40)");
	
	status();
	}
	void setVolume(int v)
	{
	if(v>0 && v<8)
	this.vol=v;
	else
	System.out.println("Invakid volume level (vol level should be bw 1-7)");
	this.status();
	}
	void channelUp()
	{
	if(this.ch<40)
	this.ch++;
	else
	this.ch=1;
	this.status();
	}
	void channelDown()
	{
	if(this.ch>1)
	this.ch--;
	else
	this.ch=40;
	this.status();
	}
	void volumeUp()
	{
	if(this.vol<7)
	this.vol++;
	else
	System.out.println("max volume reahced..can't increase further..");
	this.status();
	}
	void volumeDown()
	{
	if(vol>1)
	this.vol--;
	else
	System.out.println("lowest volume reahced..can't decrease further..");
	this.status();
	}
	
}

public class m23
{
	public static void main(String arg[])
	{
		Tv t=new Tv(true,23,5);
		Scanner sc=new Scanner(System.in);
		
		int c=1;
		while(c!=0)
		{
			System.out.println("Enter 1-setchannel,2-setvolume,3-channelup,4-channelDown,5-volumeUp,,6-volumeDown, 7-turnOff");
			c=sc.nextInt();
			switch(c)
			{
				case 1:
				t.setChannel(sc.nextInt());
				break;
				
				case 2:
				t.setVolume(sc.nextInt());
				break;
				
				case 3:
				t.channelUp();
				break;
				
				case 4:
				t.channelDown();
				break;
				
				case 5:
				t.volumeUp();
				break;
				
				case 6:
				t.volumeDown();
				break;
				
				case 7:
				c=0;
			}
		}
		
	}
}
