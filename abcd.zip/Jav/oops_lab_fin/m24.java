



//comparrison metric: mileage*time== mileage*(dist/time)

import java.util.*;


