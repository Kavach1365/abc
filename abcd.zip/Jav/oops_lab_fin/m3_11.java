import java.util.*;

class product
{
	int id,qty,price;
	String name;
	
	product(int i,String n,int p,int qt)
	{
	id=i; name=n; price=p; qty=qt;
	}
}

public class m3_11
{
	public static void main(String arg[])
	{
		Scanner sc=new Scanner(System.in);
		product p[]=new product[5];
		System.out.println("Enter pid,name,price,qty: ");
		for(int i=0;i<5;i++)
		{
			p[i]=new product(sc.nextInt(),sc.next(),sc.nextInt(),sc.nextInt());
		}
		
		int sum=0;
		int id;
		System.out.println("Enter pid(1-5),qty 0-exit: ");
		while((id=sc.nextInt())!=0)
		{
			//System.out.pritnln("Enter pid(1-5),qty 0-exit: ");
			//id=sc.nextInt();
			int q=sc.nextInt();
			if(id!=0)
			{
				p[id-1].qty-=q;
				sum=sum+q*p[id-1].price;	
			}
				
		}
		System.out.println("Total price="+sum);
			
	}
}
