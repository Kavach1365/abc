import java.util.*;

class Lamp
{
	boolean ison;
	String lamptype;
	
	Lamp(String lt,boolean ison)
	{
		this.ison=ison;
		lamptype=lt;
	}
	
	void turnOn()
	{
		if(!ison) {ison=true; System.out.println(lamptype+" is on now");}
		//else System.out.println(lamptype+" is already on");
	}
	void turnOff()
	{
		if(ison) {ison=false; System.out.println(lamptype+" is off now");}
		//else System.lout.println(lamptype+"is already off");
	}
	
	String status()
	{
		if(ison)
		return "ON";
		else
		return "OFF";
	}
}

public class m22
{
	public static void main(String arg[])
	{
		Lamp l1=new Lamp("Led",true);
		Lamp l2=new Lamp("halogen",false);
		Scanner sc=new Scanner(System.in);
		
		int c=1;
		while(c!=0)
		{
			System.out.println();	
			System.out.println("CURRENT STATUS: ");
			System.out.println(l1.lamptype+": "+l1.status());
			System.out.println(l2.lamptype+": "+l2.status());
			System.out.println();	
			
			System.out.println("Enter 1-to change led status ,2-halogen,0-exit ");
			c=sc.nextInt();
			switch(c)
			{
				case 1:
				if(!l1.ison) l1.turnOn(); 
				else l1.turnOff();
				break;
				
				case 2:
				if(l2.ison) l2.turnOff();
				else l2.turnOn();
			}		
		}	
	}
}
