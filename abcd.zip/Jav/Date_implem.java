package pack3;

import java.util.*;
class Date_implem
{
	void showdate()
	{
		Date d=new Date();
		System.out.println(d);
	}
}
