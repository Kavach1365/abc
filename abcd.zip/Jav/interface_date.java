
package pack3;
import java.util.*;

interface interface_date
{
	void showdate();
}
