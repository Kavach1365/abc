import java.util.*;


class Dog{
	String name,breed,color,type;
	double height;
	Dog(){
		name="xyz";
		breed="abc";
		color="brown";
		height=1.5f;
		type="gaurd";
	}
	Dog(String n,String b,String c,String t,double h)
	{
	this.name=n; this.breed=b; this.color=c; this.type=t; this.height=h;
	}
	String getName()
	{
	return name;
	}
	String getBreed()
	{
		return breed;
	}
	String getType()
	{
		return type;
	}
	String getColor()
	{
		return color;
	}
	double getHeight()
	{
		return height;
	}
		
}

class lab25{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no.of dogs available");
		int n=sc.nextInt();
		Dog d[]=new Dog[n];
		for(int i=0;i<n;i++)
		{
			System.out.printf("Enter dog%d name: ",i);
			String nm=sc.next();
			System.out.printf("Enter dog%d breed: ",i);
			String b=sc.next();
			System.out.printf("Enter dog%d type: ",i);
			String t=sc.next();
			System.out.printf("Enter dog%d color: ",i);
			String c=sc.next();
			System.out.printf("Enter dog%d height: ",i);
			double h=sc.nextDouble();	
			d[i]=new Dog(nm,b,c,t,h);	
		}
		System.out.println("Enter char of dog that you want::");
		String br,cr,tp;
		double ht;
		System.out.println("Enter breed: ");
		br=sc.next();
		System.out.println("Enter type: ");
		tp=sc.next();
		System.out.println("Enter color: ");
		cr=sc.next();
		System.out.println("Enter height: ");
		ht=sc.nextDouble();
		int count[]=new int[n];
		for(int i=0;i<n;i++) count[i]=0;
		for(int i=0;i<n;i++)
		{
			if(cr.equals(d[i].getColor())) count[i]=count[i]+1;
			if(br.equals(d[i].getBreed())) count[i]=count[i]+1;
			if(d[i].getType()==tp) count[i]=count[i]+1;
			if(d[i].getHeight()==ht) count[i]=count[i]+1;
		}	
		int max=count[0],g=0;
		for(int i=0;i<n;i++)
		{
		if(count[i]>max) {max=count[i]; g=i;}
		}
		System.out.println(d[g].getName());
	}
	
	


}
