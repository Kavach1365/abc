import java.util.*;

class xy
{
	static int x=8;
	void prin()
	{
	System.out.println(x);
	}
}

class statvar
{
public static void main(String rgs[])
{
	xy o=new xy();
	o.prin();
	
	xy o2=new xy();
	o2.prin();
}
}
