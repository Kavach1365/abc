import java.util.*;



class temp
{
	 void  t()
	{System.out.println("abcd");}
}

class temp2
{
	static void tt()
	{
	temp o=new temp();
	o.t();
	}
}

class mt2
{
	public static void main(String args[])
	{	
		int x[];
		x=new int[2];
		
		int y[]={5,6,7};
		
		int z[]=new int[3];
		
		x[0]=9;
		x[1]=8;
		//x[2]=77; exception >>no compie error
		
		
		//variable array
		int a[][]=new int[2][];
		for(int i=0;i<a.length;i++)
		{
			a[i]=new int[i+1];
		}
		temp2 o=new temp2();
		o.tt();
		//temp.t(); works if t() is static
		
		temp2.tt();
		
		//vectors
		
		
		
	}
}
