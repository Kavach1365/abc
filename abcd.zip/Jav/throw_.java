import java.util.*;
//import java.lang.Exception;
class myex extends Exception
{
	myex(String mesg)
	{
		super(mesg);//passsing mesg to the Exception predefined class method
				//so that it can be called using getMessage()#predfined method in class Exception 
	}
}


class throw_
{
	public static void main(String arga[])
	{
		int x=10,y=-3,z=4;
		try
		{
			int a=x/y,b=x/z;
			System.out.println("a="+a+" b="+b);
			if(a<0 || b<0) throw new myex("please enter positive values for x,y,z");//passing msg to constructr myex//calling it
		}
		catch(myex e)
		{
			System.out.println(e.getMessage());//if that mesg not passed	getMessage returns NULL
			System.out.println(e.getCause());
		}
			
	}
}
