import java.util.*;
import java.lang.*;
import java.io.*;


public class A{
protected void msg(){
System.out.println("HIII from AA");
}

}

class B extends A{

public static void main(String args[]){

public void msg(){
System.out.println("Hiiii From BBB");
}

A obj=new A();
obj.msg();

}


}
