package Mypacakge2;
import Jav.Mypackage.X;
public class A extends Jav.Mypackage.X{
A(){
System.out.println("Y constructor:");
//System.out.println("n="+n);
//System.out.println("p="+p);
//System.out.println("q="+q);
System.out.println("r="+r);
}

}
