package Mypackage2;

public class B{
B(){
Mypackage1.X x=new Mypackage1.X();
System.out.println("B constructor:");
System.out.println("n="+x.n);
System.out.println("p="+x.p);
System.out.println("q="+x.q);
System.out.println("r="+x.r);
}

}
