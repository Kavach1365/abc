package Mypackage2;
import Mypackage1.*;
public class demo{
public static void main(String args[]){
Mypackage1.X x1=new Mypacakge1.X();

}
}
