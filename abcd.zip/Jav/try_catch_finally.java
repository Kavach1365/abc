import java.util.*;

class try_catch_finally
{
	public static void main(String args[])
	{
		try
		{
		Scanner sc=new Scanner(System.in);
		int x=sc.nextInt();
		//return 5;
		}
		catch(InputMismatchException e)
		{
			System.out.println("invalid.....");
						//System.out.println(e.getCause());
		}
		finally{
		System.out.println("in fanallyyyyy...");
		}
		System.out.println("HEy...");
		//USE OF FINALLY BLOCK
		/*
		return stmts in finally will override return stmts of try or catch
		i.e though return in try/catch excuted it wont get out of method it excutes finally also even after return by try/catchss
		>>>if return there in finally
		any thing after return can't be =excuted::: therefore COMPILATION ERROR: UNREACHABLE CODE
		
		*/
	}

}
