import java.util.*;


class lab3_12
{
	public static void main(String args[])
	{
		int count=0;
		int a[]=new int[5];
		Random r=new Random();
		while(count<5)
		{
			int x=r.nextInt(90)+10;
			if(count==0)
			{	
				a[0]=x;
				count++;
			}
			else
			{
				int i=0,f=1;
				for(i=0;i<count;i++)
				{
					if(a[i]==x) {f=0; break;};
				}
				if(f==1)
				{
				a[count++]=x;
				for(i=0;i<count;i++)
					System.out.print(a[i]+" ");
				System.out.println();
				}
			}
		}
	}
}
