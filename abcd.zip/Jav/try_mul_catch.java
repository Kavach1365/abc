import java.util.*;


class try_mul_catch
{
	public static void main(String args[])
	{
		try
		{
			if(args[0]=="java") System.out.println("first word is java");  //Array bound ecxptin if comnd args not entered
			int i=args.length;
			//String st=new String[i];  //DOUBT ?????????
			Scanner sc=new Scanner(System.in);
			int n=sc.nextInt();
			int m=7;
			m=m/n; //if n=0:  divide by 0 error--->> ARITHMETIC exception
			int a[]={53,234,54,89};
			a[n]=7777;   //if n=8:: >>ARRAY BOUND exception 
		}
		catch(ArithmeticException e)
		{
			System.out.println("DIVISION BY ZERO...");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array INDEX out of BOUND....");
		}
		catch(NullPointerException e)
		{
			System.out.println("NULL POINTER exception....");			
		}
	}
}
