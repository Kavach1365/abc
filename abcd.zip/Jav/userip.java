import java.util.*;
import java.io.*;//for DataInputStream

class userip{
public static void main(String args[]){
//to take all inputs at beginnnig can be done by String args[] directly 
for(int i=0;i<args.length;i++) System.out.print(args[i]+" , ");
//System.exit(0);    //  >>to stop reading/scanning from user but not required

//for this import java.util.Scanner;
Scanner f=new Scanner(System.in);
int x,y,z,w;
x=f.nextInt();
y=f.nextInt();
z=f.nextInt();

System.out.println("x="+x+" y="+y+" z="+z);
System.out.print("enter w= ");//using scanner we take ip at anywhere in program not only at beginning
w=f.nextInt();


DataInputStream k=new DataInputStream(System.in);
String psk;
//System.out.flush();
psk=k.readLine();
System.out.println("input taken is= "+psk);
}
}
