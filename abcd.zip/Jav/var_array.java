import java.lang.*;

class var_array{
public static void main(String args[]){


}
}
