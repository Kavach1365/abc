import java.util.*;
import java.lang.Exception;
class myex extends Exception
{
	myex(String mesg)
	{
		super(mesg);
		//java.lang.Exception.message
	}
}


class throw_
{
	public static void main(String arga[])
	{
		int x=1,y=-3,z=4;
		try
		{
			int a=x/y,b=x/z;
			if(a<0 || b<0) throw new myex("please enter positive values for x,y,z");
		}
		catch(myex e)
		{
			System.out.println(e.getMessage());	
		}
			
	}
}
